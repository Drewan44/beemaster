import { useState } from "react";

const C = {
  bg:"#0D0700",card:"#1A0C00",border:"#8B5E00",gold:"#D4A017",amber:"#FF8C00",
  honey:"#F5A623",cream:"#FFF8E7",muted:"#A07840",red:"#C0392B",green:"#27AE60",
  blue:"#2980B9",purple:"#8E44AD",dark:"#0A0500",teal:"#16A085",
};

const HIVE_TYPES=["Langstroth","Warre","Top Bar","National","Flow Hive","Dadant","Other"];
const HEALTH=["Excellent","Good","Fair","Poor","Critical"];
const QUEEN_STATUS=["Present & Laying Well","Present, Poor Laying","Queen Cells Present","Queenless - Needs Requeening","New Queen (Unmarked)","New Queen (Marked)","Unknown"];
const TEMPERAMENT=["Very Calm","Calm","Gentle","Slightly Defensive","Defensive","Aggressive"];
const DISEASE_LIST=["None Detected","Varroa (High)","American Foulbrood","European Foulbrood","Chalkbrood","Sacbrood","Nosema","Small Hive Beetle","Wax Moth","Deformed Wing Virus","Chronic Bee Paralysis"];
const TREATMENTS=["None","Oxalic Acid Vaporization","Oxalic Acid Dribble","Apiguard (Thymol)","ApiVar (Amitraz Strips)","Formic Pro","Apilife Var","Fumagilin-B (Nosema)","Terramycin (EFB)","Small Hive Beetle Trap","Wax Moth Trap","Feeding (Sugar Syrup)","Feeding (Fondant)","Pollen Supplement","Other"];
const FEED_TYPES=["1:1 Sugar Syrup (Spring)","2:1 Sugar Syrup (Autumn)","Candy Board","Fondant","Pollen Patty","Protein Supplement","None"];
const HONEY_TYPES=["Wildflower","Clover","Heather","Manuka","Acacia","Orange Blossom","Buckwheat","Lavender","Mixed Blossom","Other"];
const SEASONS=["Spring","Summer","Autumn","Winter"];
const WEATHER=["Sunny","Partly Cloudy","Overcast","Windy","Rainy","Cold","Hot","Humid"];
const today=new Date().toISOString().split("T")[0];

const DEMO_HIVES=[
  {id:1,name:"Queen Beatrice",location:"South Garden",type:"Langstroth",color:"#FFD700",added:"2024-03-15",notes:"My strongest colony. Italian bees."},
  {id:2,name:"Hive Oberon",location:"Orchard",type:"Warre",color:"#FF6B35",added:"2024-06-01",notes:"Buckfast strain. Excellent honey producers."},
];
const DEMO_INSPECTIONS=[
  {id:1,hiveId:1,date:"2026-05-28",season:"Spring",weather:"Sunny",tempC:22,health:"Excellent",queen:"Present & Laying Well",queenColor:"Blue (2024)",temperament:"Calm",brood:9,honey:8,pollen:7,population:9,disease:"None Detected",treatment:"None",treatmentDose:"",treatmentDate:"",withdrawalDays:0,supers:2,frameCount:10,feedType:"None",feedAmount:0,swarmCells:false,swarmRisk:"Low",notes:"Colony booming. Added second super.",varroa:1,varroaMethod:"Alcohol Wash",weight:42.5},
  {id:2,hiveId:2,date:"2026-05-25",season:"Spring",weather:"Partly Cloudy",tempC:18,health:"Good",queen:"Present & Laying Well",queenColor:"Unknown",temperament:"Gentle",brood:7,honey:6,pollen:6,population:7,disease:"Varroa (High)",treatment:"Oxalic Acid Vaporization",treatmentDose:"2.3g",treatmentDate:"2026-05-25",withdrawalDays:0,supers:1,frameCount:8,feedType:"None",feedAmount:0,swarmCells:false,swarmRisk:"Low",notes:"Varroa count high. Treated with OA.",varroa:4,varroaMethod:"Sugar Roll",weight:35.1},
];
const DEMO_HARVESTS=[
  {id:1,hiveId:1,date:"2025-08-10",frames:8,weight:18.5,honeyType:"Wildflower",moisture:17.2,extracted:"Radial Extractor",jarCount:37,notes:"Beautiful golden colour."},
  {id:2,hiveId:2,date:"2025-08-12",frames:5,weight:11.0,honeyType:"Clover",moisture:17.8,extracted:"Crush & Strain",jarCount:22,notes:"Light and delicate."},
];
const DEMO_EXPENSES=[
  {id:1,date:"2026-01-10",category:"Equipment",item:"New Super & Frames",cost:45.00,notes:""},
  {id:2,date:"2026-02-20",category:"Treatment",item:"Oxalic Acid",cost:18.50,notes:"3 applications"},
  {id:3,date:"2026-03-05",category:"Feed",item:"Sugar (10kg)",cost:12.00,notes:"Spring build-up feed"},
];
const DEMO_TASKS=[
  {id:1,hiveId:1,task:"Check super space — may need another",due:"2026-06-10",done:false,priority:"High"},
  {id:2,hiveId:2,task:"Follow-up varroa count after OA treatment",due:"2026-06-08",done:false,priority:"High"},
  {id:3,hiveId:1,task:"Mark queen with yellow marker (2026)",due:"2026-06-15",done:false,priority:"Medium"},
  {id:4,hiveId:null,task:"Order new foundation sheets",due:"2026-06-20",done:false,priority:"Low"},
];
const DEMO_QUEENS=[
  {id:1,hiveId:1,introduced:"2024-03-15",breed:"Italian",marked:true,markColor:"Blue (2024)",status:"Active",notes:"Prolific layer. Very gentle colony."},
  {id:2,hiveId:2,introduced:"2024-06-01",breed:"Buckfast",marked:false,markColor:"Unknown",status:"Active",notes:"Good honey production."},
];

// ── RESEARCH DATA ──────────────────────────────────────────────────────────
const RESEARCH_ARTICLES=[
  {
    id:1, category:"Hive Health & Disease",
    title:"Impact of Environmental Factors and Management Practices on Bee Health",
    authors:"Ivana Tlak Gajger, Franco Mutinelli",
    journal:"Insects (MDPI)", year:2024, doi:"10.3390/insects15120996",
    url:"https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11678557/",
    summary:"Comprehensive review of how pesticides, habitat loss, pathogens, and management practices interact to affect honeybee colony health. Covers the 'One Health' approach linking bee, human and environmental health.",
    keyFindings:["Varroa + virus combinations are the leading cause of colony collapse","Pesticide exposure significantly weakens bee immune response","Diverse forage landscapes improve colony survival rates"],
    access:"Open Access (PubMed Central)",
    color:C.red,
  },
  {
    id:2, category:"Technology & Precision Beekeeping",
    title:"IoT and Machine Learning Techniques for Precision Beekeeping: A Review",
    authors:"Multiple Authors (MDPI)",
    journal:"AI (MDPI)", year:2025, doi:"Published Feb 2025",
    url:"https://www.mdpi.com/2673-2688/6/2/26",
    summary:"Critical analysis of IoT-enabled smart hive monitoring systems. Covers sensor networks, sound analysis for queen detection, swarm prediction, and automated varroa counting using machine learning.",
    keyFindings:["AI can detect queenlessness from hive acoustics with 90%+ accuracy","Weight sensors can predict swarming 48–72 hours in advance","Remote monitoring reduces hive disturbance and colony stress"],
    access:"Open Access (MDPI)",
    color:C.blue,
  },
  {
    id:3, category:"Technology & Precision Beekeeping",
    title:"Transforming Beekeeping Through Technology: A Systematic Review of Precision Beekeeping",
    authors:"Multiple Authors (MDPI)",
    journal:"Insects (MDPI)", year:2025, doi:"2025",
    url:"https://www.mdpi.com/2413-4155/8/4/87",
    summary:"Systematic review of 46 precision beekeeping studies from Scopus and Web of Science. Covers machine learning, cloud computing, IoT and communication methods for automated hive management.",
    keyFindings:["Research in precision beekeeping surged 400% since 2016","Cloud-connected hives enable real-time health alerts to beekeepers","Integration of AI, IoT and sensors can reduce varroa losses significantly"],
    access:"Open Access (MDPI)",
    color:C.blue,
  },
  {
    id:4, category:"Sustainability & Environment",
    title:"Greenhouse Gas Emissions and Energy Consumption in Beekeeping",
    authors:"Benoit M & Grosmond G",
    journal:"Frontiers in Animal Science", year:2025, doi:"10.3389/fanim.2025.1524343",
    url:"https://www.frontiersin.org/journals/animal-science/articles/10.3389/fanim.2025.1524343/full",
    summary:"First detailed lifecycle analysis of beekeeping's carbon footprint. Compares amateur (1 apiary) versus professional (300 hive) systems, finding travel to apiaries is the biggest emission source.",
    keyFindings:["Amateur beekeeping emits 2.7 kgCO₂/kg honey vs 1.49kg for professionals","Travel accounts for 59% of emissions for hobbyists — use local sites","Sugar feeding accounts for 21–41% of total emissions"],
    access:"Open Access (Frontiers)",
    color:C.green,
  },
  {
    id:5, category:"Research & Innovation",
    title:"Bridging Research and Practice: Developing Beekeeping Knowledge and Innovation Systems",
    authors:"Fabricius Kristiansen L et al.",
    journal:"Frontiers in Conservation Science", year:2024, doi:"10.3389/fcosc.2024.1490089",
    url:"https://www.frontiersin.org/journals/conservation-science/articles/10.3389/fcosc.2024.1490089/full",
    summary:"Introduces the Beekeeping Knowledge and Innovation System (B-KIS) concept to connect scientific research with practical beekeeping. Examines how knowledge flows between researchers, advisors, and beekeepers.",
    keyFindings:["Major gap exists between scientific findings and beekeeper practice","Structured advisory networks improve colony survival outcomes","Collaborative innovation improves adoption of varroa management"],
    access:"Open Access (Frontiers)",
    color:C.purple,
  },
  {
    id:6, category:"Hive Health & Disease",
    title:"Bee and Beekeeping Research in a Rapidly Changing World",
    authors:"Multiple Authors (Molecules, MDPI)",
    journal:"Molecules (MDPI)", year:2021, doi:"PMC8196620",
    url:"https://pmc.ncbi.nlm.nih.gov/articles/PMC8196620/",
    summary:"Overview of 12 key research directions in modern apiculture: pesticide detection in honey, novel natural treatments for pathogens, and the chemical properties of bee products including pollen, venom, propolis and honey.",
    keyFindings:["Natural thymol products show promise as safer varroa treatments","Bee pollen has significant nutraceutical and antioxidant properties","Propolis demonstrates antimicrobial activity against resistant bacteria"],
    access:"Open Access (PubMed Central)",
    color:C.amber,
  },
  {
    id:7, category:"Journals to Follow",
    title:"Journal of Apicultural Research — Leading Peer-Reviewed Bee Science Journal",
    authors:"Taylor & Francis Online",
    journal:"Journal of Apicultural Research", year:2024, doi:"tandfonline.com/journals/tjar20",
    url:"https://www.tandfonline.com/journals/tjar20",
    summary:"The world's leading refereed scientific journal dedicated to bee research. Covers bee behaviour, ecology, genetics, pathology, bee management, hive product science, and toxicology across all bee species worldwide.",
    keyFindings:["Covers all bee species globally — not just honeybees","Publishes both original research and theoretical papers","Key resource for staying updated on varroa, disease and colony management research"],
    access:"Subscription (partial free access)",
    color:C.honey,
  },
];

const SUPPLIERS=[
  // UK
  {id:1,region:"UK",name:"Thornes",type:"Full Range",rating:5,url:"https://www.thornes.co.uk",description:"Britain's most established beekeeping supplier since the 1920s. Manufactures hives, wax foundation, suits, extractors and accessories at their Wragby site. Branches in Wragby, Windsor and Tayport (Scotland). Best for everything from beginner kits to professional equipment.",speciality:"Hive manufacturing, suits, extractors",priceRange:"£££",beginner:true},
  {id:2,region:"UK",name:"National Bee Supplies",type:"Hive Specialist",rating:5,url:"https://beekeeping.co.uk",description:"Leading craftsmen of cedar beehives based in Devon. Known for exceptional quality cedar hives using traditional techniques. Their motto: 'The best value hive is the one you don't have to replace.' Click & collect available Mon–Fri.",speciality:"Premium cedar hives",priceRange:"£££",beginner:false},
  {id:3,region:"UK",name:"Maisemore Apiaries (bees-online.co.uk)",type:"Full Range",rating:4,url:"https://www.bees-online.co.uk",description:"Official website of Maisemore Apiaries. Supplies hive frames, protective clothing, honey extraction equipment, beeswax foundation, hive tools, and live bees on comb. Family-run, well-regarded for quality and advice.",speciality:"Live bees, complete hive kits",priceRange:"££",beginner:true},
  {id:4,region:"UK",name:"Paynes Bee Farm",type:"Full Range",rating:4,url:"https://www.paynes-bees.co.uk",description:"Established 1922, family-run commercial beekeeping company. Supplies honey from their own Sussex hives plus a wide range of equipment. Traditional values with modern stock. Based in the South Downs.",speciality:"Equipment + own-brand honey",priceRange:"££",beginner:true},
  {id:5,region:"UK",name:"Beekeeping Supplies UK",type:"Equipment",rating:4,url:"https://www.beekeepingsuppliesuk.com",description:"Highly rated online supplier with competitive prices and fast delivery. Customers praise quality frames, wax foundation, tools, and supers. Offers collection service for local customers. Great value for money.",speciality:"Frames, foundation, tools",priceRange:"£",beginner:true},
  {id:6,region:"UK",name:"Apiary Gear Supplies (AGS)",type:"Protective Clothing",rating:4,url:"https://agsonline.co.uk",description:"Specialises in beekeeping suits, protective jackets, hive tools, smokers and wax foundation. Stocks beginner kits through to professional grade. Fast UK delivery. Good for protective gear at competitive prices.",speciality:"Suits, jackets, protective gear",priceRange:"££",beginner:true},
  {id:7,region:"UK",name:"BS Honey Bees",type:"Live Bees & Equipment",rating:4,url:"https://bshoneybees.co.uk",description:"Based in the Gloucestershire Cotswolds. Specialises in live bee sales — F1 Buckfast Queens, Carniolan Queens, and Nucleus colonies (Nucs) delivered across the UK. Also supplies equipment and runs beekeeping shows.",speciality:"F1 Buckfast queens, nucleus colonies",priceRange:"££",beginner:true},
  {id:8,region:"UK",name:"Gwenyn Gruffydd",type:"Full Range",rating:4,url:"https://gwenyngruffydd.co.uk",description:"Comprehensive beekeeping store. Stocks Swienty, Thornes, Paynes, Vita Europe, HiveAlive and more. Also has a YouTube channel with beekeeping tips and equipment reviews. Open weekdays 9am–4:30pm.",speciality:"Multi-brand stockist",priceRange:"££",beginner:true},
  {id:9,region:"UK",name:"Affordable Bee Supplies",type:"Budget & Beginner",rating:4,url:"https://www.affordablebeesupplies.co.uk",description:"Family-run business with over 40 years of beekeeping experience. Focused on affordability for beginners and hobbyists. Free advice to new beekeepers. Quality products at accessible prices with expert guidance.",speciality:"Budget beginner kits, free advice",priceRange:"£",beginner:true},
  {id:10,region:"UK",name:"Honey Fountain",type:"Equipment & Clothing",rating:4,url:"https://honeyfountain.co.uk",description:"Premium beekeeping equipment and clothing supplier. Free delivery on orders over £40 on equipment and treatments. Good range of protective clothing designed for comfort during inspections.",speciality:"Protective clothing, treatments",priceRange:"££",beginner:true},
  // US
  {id:11,region:"US",name:"Mann Lake Bee & Ag Supply",type:"Full Range",rating:5,url:"https://www.mannlakeltd.com",description:"One of America's largest beekeeping suppliers. Huge range of hives, equipment, treatments, feeds and protective gear. Well-known for their educational content and beekeeping guides. Excellent for US-based beekeepers of all levels.",speciality:"Complete beekeeping supplies",priceRange:"$$$",beginner:true},
  {id:12,region:"US",name:"Dadant & Sons",type:"Full Range",rating:5,url:"https://www.dadant.com",description:"America's oldest beekeeping supplier, founded 1863. Family-owned for 6 generations. Manufactures hives, frames and wax foundation. Publishes the American Bee Journal. Multiple US branches for in-store pickup.",speciality:"Hive manufacturing, American Bee Journal",priceRange:"$$$",beginner:true},
  {id:13,region:"US",name:"Brushy Mountain Bee Farm",type:"Equipment",rating:4,url:"https://www.brushymountainbeefarm.com",description:"North Carolina-based supplier of hives, tools, extraction equipment and protective gear. Popular with American hobbyists. Good range of wooden ware and beginner packages. Strong online community.",speciality:"Wooden ware, beginner packages",priceRange:"$$",beginner:true},
  {id:14,region:"US",name:"Walter T. Kelley",type:"Equipment",rating:4,url:"https://www.kelleybees.com",description:"Kentucky-based manufacturer and supplier of beekeeping equipment since 1924. Known for quality wooden ware, extractors and beekeeping tools. One of the US's most respected traditional suppliers.",speciality:"Traditional wooden ware, extractors",priceRange:"$$",beginner:true},
  // International
  {id:15,region:"International",name:"Flow Hive (Australia)",type:"Innovative Hives",rating:4,url:"https://www.honeyflow.com",description:"Inventors of the revolutionary Flow Hive — honey harvested without opening the hive or disturbing bees. Ships worldwide. Premium price but reduces stress on bees at harvest. Popular with beginners and hobbyists globally.",speciality:"Flow Hive innovation",priceRange:"$$$$",beginner:true},
  {id:16,region:"International",name:"Swienty (Denmark)",type:"Professional Equipment",rating:5,url:"https://www.swienty.com",description:"Leading European manufacturer of professional beekeeping equipment. Specialises in honey extraction machinery, high-capacity extractors and processing equipment. Used by commercial apiaries across Europe.",speciality:"Professional extraction equipment",priceRange:"££££",beginner:false},
];

const STARTUP_GUIDE={
  hobbyist:{
    label:"Hobbyist (1–2 Hives)",
    icon:"🏡",
    color:C.green,
    startupCost:"£300–£700 / $400–$1,000",
    annualCost:"£150–£300 / $200–$400",
    expectedYield:"15–30kg honey / 30–60 jars per year",
    timeCommitment:"2–4 hours/week in active season",
    items:[
      {item:"Complete Hive (brood box, super, frames, roof, floor)",cost:"£150–£250"},
      {item:"Nucleus Colony (Nuc) or Package of Bees",cost:"£200–£280"},
      {item:"Full Bee Suit with Veil",cost:"£40–£100"},
      {item:"Hive Tool",cost:"£5–£10"},
      {item:"Smoker",cost:"£15–£30"},
      {item:"Feeder",cost:"£10–£20"},
      {item:"Queen Marking Kit",cost:"£5"},
      {item:"Basic Extraction Kit (manual extractor or crush & strain)",cost:"£50–£150"},
    ],
    steps:["Join your local beekeeping association (BBKA in UK, AABA in US) — often includes training","Complete a beginner's course — many associations offer free/subsidised courses","Purchase equipment from a reputable supplier","Order a nucleus colony or package from a local beekeeper for spring","Site your hive in a sunny, sheltered south-facing location","Inspect every 7–10 days in spring & summer","Harvest in July/August — aim to leave 20kg for winter"],
    revenueStreams:["Sell honey direct to friends/neighbours (£5–£8/jar)","Beeswax candles, lip balms from cappings","Local farmers markets"],
  },
  smallComm:{
    label:"Small Commercial (5–20 Hives)",
    icon:"🏪",
    color:C.amber,
    startupCost:"£3,000–£8,000 / $5,000–$12,000",
    annualCost:"£1,500–£4,000 / $2,000–$6,000",
    expectedYield:"150–600kg honey / 300–1,200 jars per year",
    timeCommitment:"15–30 hours/week in active season",
    items:[
      {item:"5–20 Complete Hives",cost:"£750–£5,000"},
      {item:"Bee Colonies (nucs or packages)",cost:"£1,000–£5,600"},
      {item:"Radial Honey Extractor (6–12 frame)",cost:"£300–£800"},
      {item:"Uncapping Tank & Tools",cost:"£150–£400"},
      {item:"Settling Tank / Bottling Bucket",cost:"£80–£200"},
      {item:"Refractometer (moisture check)",cost:"£20–£50"},
      {item:"Professional Bee Suit x2",cost:"£100–£200"},
      {item:"Vehicle for transport",cost:"£2,000–£8,000"},
      {item:"Treatments (OA, ApiVar) annual",cost:"£100–£300"},
      {item:"Labels, jars, packaging",cost:"£200–£500"},
      {item:"Food hygiene registration (UK free, US varies)",cost:"Free–£200"},
    ],
    steps:["Register as food business (UK: local council, free; US: state department of agriculture)","Get a refractometer — moisture must be under 20% to sell legally","Join BBKA, BFA or local association for insurance and support","Consider organic certification — adds 40% to product value","Set up at farmers markets, local shops, or online via Etsy/website","Track all costs & revenue — profit margins of 15–25% typical","Expand by 2–3 hives per year as you gain experience"],
    revenueStreams:["Direct honey sales (highest margin — £6–£10/jar)","Farmers markets & deli shops","Beeswax products — candles, polish, cosmetics","Nucleus colony sales in spring (£200–£280 each)","Queen rearing and queen sales","Corporate honey gifting","Pollination services for local orchards/gardens"],
  },
  commercial:{
    label:"Full Commercial (50+ Hives)",
    icon:"🏭",
    color:C.red,
    startupCost:"£40,000–£75,000 / $50,000–$100,000",
    annualCost:"£15,000–£30,000 / $20,000–$40,000",
    expectedYield:"2,000–5,000kg honey / year",
    timeCommitment:"Full-time — 40+ hours/week",
    items:[
      {item:"50–200 Hives + equipment",cost:"£15,000–£60,000"},
      {item:"Commercial multi-frame extractor (24–64 frame)",cost:"£3,000–£15,000"},
      {item:"Processing room (food-grade fittings)",cost:"£5,000–£20,000"},
      {item:"Vehicle + trailer for migratory beekeeping",cost:"£8,000–£25,000"},
      {item:"Cold room / storage facility",cost:"£2,000–£10,000"},
      {item:"Commercial bottling and labelling equipment",cost:"£1,000–£5,000"},
      {item:"Business insurance (liability, equipment)",cost:"£500–£2,000/year"},
    ],
    steps:["Develop a formal business plan with financial projections","Secure funding — grants available via BBKA, Rural Payments Agency (UK), USDA (US)","Register as a food business and undergo local authority inspection","Invest in traceable, branded honey for premium pricing","Explore diversified income: pollination contracts, bee rental, teaching","Consider cooperative membership for bulk honey sales","Hire part-time help for spring/summer peak seasons"],
    revenueStreams:["Wholesale honey to shops, restaurants, distributors","Pollination services ($150–$200/hive per season in US)","Queen breeding and sale","Beekeeping courses and workshops","Branded premium honey (Manuka, mono-floral)","Corporate bee sponsorship schemes","Propolis, royal jelly, bee venom for specialist markets"],
  },
};

const DIY_GUIDE=[
  {
    step:1, title:"Choose Your Hive Type",
    icon:"🏠", time:"Research time: 1–2 days",
    content:"The Langstroth is the best for beginners — most common globally, easiest to find parts and advice for. The Warre (vertical top-bar) is more natural but harder to manage. The Top Bar hive suits warmer climates and is the easiest to build from scratch. The National hive is standard in the UK.",
    resources:[
      {label:"Family Handyman: How to Build a Langstroth Hive",url:"https://www.familyhandyman.com/project/how-to-build-a-beehive/"},
      {label:"This Old House: Complete DIY Hive Plans",url:"https://www.thisoldhouse.com/woodworking/23032293/building-a-beehive"},
      {label:"Today's Homeowner: DIY Beehive Guide 2026",url:"https://todayshomeowner.com/lawn-garden/guides/how-to-build-a-beehive/"},
      {label:"Insteading: 18 Creative DIY Hive Plans",url:"https://insteading.com/blog/diy-beehive-plans/"},
    ]
  },
  {
    step:2, title:"Materials & Tools Needed",
    icon:"🪵", time:"Cost: £30–£80 DIY vs £150–£250 bought",
    content:"Use western red cedar (best) or pine. Cedar is rot-resistant, light and insulating — worth the extra cost. You'll need: table saw, miter saw, jigsaw, drill, wood glue, exterior screws. Cut all components before assembly. A basic Langstroth takes 8–12 hours for a beginner.",
    resources:[
      {label:"Beekeeper Corner: DIY Plans for All Hive Types",url:"https://beekeepercorner.com/diy-bee-hive-plans-for-beginners/"},
      {label:"Revival Woodworks: Build Your Hive — Part 1",url:"https://www.revivalwoods.com/blog/how-to-build-a-beehive-1"},
    ]
  },
  {
    step:3, title:"Key Components to Build",
    icon:"🔧", time:"Build time: 8–16 hours",
    content:"A Langstroth hive needs: (1) Bottom Board with entrance, (2) Brood Box (deep super) — where queen lays eggs, (3) Queen Excluder — keeps queen below honey supers, (4) Honey Super (shallower box) — where honey is stored, (5) Inner Cover, (6) Outer/Telescoping Cover — weatherproof lid. Frames go inside each box.",
    resources:[
      {label:"Free Langstroth Plans — The Spruce",url:"https://www.thespruce.com/free-beehive-plans-1388017"},
      {label:"University of Minnesota Beekeeping Guide",url:"https://extension.umn.edu/bees/beginning-beekeeping"},
    ]
  },
  {
    step:4, title:"Painting & Weatherproofing",
    icon:"🎨", time:"Allow 2 days drying time",
    content:"Paint or treat the exterior only — never inside the hive. Use exterior-grade paint in light colours (white or cream reflect heat). Prime first, then 2 coats. Alternatively use raw linseed oil for a natural finish. Leave 2–3 weeks before introducing bees so fumes dissipate.",
    resources:[
      {label:"National Bee Supplies — Cedar Hive Maintenance Guide",url:"https://beekeeping.co.uk"},
    ]
  },
  {
    step:5, title:"Buy Frames & Foundation",
    icon:"🖼️", time:"Cost: £2–£4 per frame",
    content:"It's almost always better to buy frames and wax/plastic foundation rather than make them — precision matters for bee space. DN4 frames for the brood box, SN4 or super frames for honey supers (UK National). Order from Thornes, Maisemore or Beekeeping Supplies UK. Foundation is either beeswax (best) or plastic coated in wax.",
    resources:[
      {label:"Beekeeping Supplies UK — Frames & Foundation",url:"https://www.beekeepingsuppliesuk.com"},
      {label:"Thornes — UK National Frames",url:"https://www.thornes.co.uk"},
    ]
  },
];

// ── HELPERS ─────────────────────────────────────────────────────────────────
const hc=(h)=>({Excellent:"#27AE60",Good:"#F5A623",Fair:"#FF8C00",Poor:"#C0392B",Critical:"#8E44AD"}[h]||"#999");
const vc=(v)=>v<=1?C.green:v<=3?C.amber:C.red;
const pc=(p)=>({High:C.red,Medium:C.amber,Low:C.green}[p]||C.muted);
const fmt=(n)=>`£${Number(n).toFixed(2)}`;
const daysDiff=(d)=>Math.round((new Date(d)-new Date())/86400000);

const S={
  app:{minHeight:"100vh",background:C.bg,fontFamily:"'Palatino Linotype','Book Antiqua',Palatino,serif",color:C.cream,fontSize:"14px"},
  header:{background:"linear-gradient(135deg,#2A1200,#0D0700)",borderBottom:`2px solid ${C.gold}`,padding:"0 16px",display:"flex",alignItems:"center",flexWrap:"wrap",gap:"8px"},
  logoWrap:{display:"flex",alignItems:"center",gap:"10px",padding:"12px 0"},
  logoText:{fontSize:"20px",color:C.gold,fontWeight:"bold",letterSpacing:"1px"},
  logoSub:{fontSize:"9px",color:C.muted,letterSpacing:"3px",textTransform:"uppercase"},
  nav:{display:"flex",gap:"2px",flexWrap:"wrap",padding:"6px 0",marginLeft:"auto"},
  nb:(a)=>({padding:"6px 11px",borderRadius:"6px",border:`1px solid ${a?C.gold:"transparent"}`,background:a?`${C.gold}18`:"transparent",color:a?C.gold:C.muted,cursor:"pointer",fontSize:"11px",fontFamily:"inherit",transition:"all .2s",whiteSpace:"nowrap"}),
  page:{padding:"18px",maxWidth:"1000px",margin:"0 auto"},
  card:{background:C.card,border:`1px solid ${C.border}44`,borderRadius:"14px",padding:"16px",marginBottom:"12px"},
  h1:{fontSize:"20px",color:C.gold,marginBottom:"14px",display:"flex",alignItems:"center",gap:"8px"},
  h2:{fontSize:"15px",color:C.honey,marginBottom:"8px"},
  h3:{fontSize:"13px",color:C.amber,marginBottom:"6px",fontWeight:"bold"},
  label:{fontSize:"10px",color:C.muted,textTransform:"uppercase",letterSpacing:"1px",marginBottom:"3px"},
  val:{fontSize:"14px",color:C.cream},
  grid2:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:"10px"},
  grid3:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:"10px"},
  grid4:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(120px,1fr))",gap:"8px"},
  stat:{background:`${C.gold}0D`,border:`1px solid ${C.gold}30`,borderRadius:"10px",padding:"12px",textAlign:"center"},
  statNum:{fontSize:"24px",color:C.gold,fontWeight:"bold"},
  statLabel:{fontSize:"10px",color:C.muted,textTransform:"uppercase",letterSpacing:"1px"},
  btn:(v)=>({padding:"8px 16px",borderRadius:"8px",border:"none",cursor:"pointer",fontSize:"12px",fontWeight:"bold",fontFamily:"inherit",background:v==="primary"?C.honey:v==="danger"?C.red:v==="green"?C.green:`${C.honey}22`,color:v==="primary"||v==="danger"||v==="green"?"#0D0700":C.cream,transition:"all .2s"}),
  inp:{width:"100%",padding:"8px 10px",borderRadius:"7px",border:`1px solid ${C.border}55`,background:C.card,color:C.cream,fontSize:"12px",fontFamily:"inherit",boxSizing:"border-box"},
  row:{display:"flex",gap:"10px",marginBottom:"10px",flexWrap:"wrap"},
  col:{flex:1,minWidth:"120px"},
  badge:(c)=>({display:"inline-block",padding:"2px 8px",borderRadius:"10px",background:`${c}22`,border:`1px solid ${c}66`,color:c,fontSize:"11px",fontWeight:"bold"}),
  barWrap:{height:"7px",borderRadius:"4px",background:`${C.gold}1A`,overflow:"hidden"},
  overlay:{position:"fixed",inset:0,background:"#000000CC",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,padding:"16px"},
  modal:{background:"linear-gradient(160deg,#200E00,#0D0700)",border:`1px solid ${C.gold}66`,borderRadius:"18px",padding:"20px",width:"100%",maxWidth:"550px",maxHeight:"90vh",overflowY:"auto"},
  alert:(c)=>({padding:"9px 12px",borderRadius:"8px",background:`${c}18`,border:`1px solid ${c}55`,color:c,fontSize:"12px",marginBottom:"8px"}),
  textarea:{width:"100%",padding:"8px 10px",borderRadius:"7px",border:`1px solid ${C.border}55`,background:C.card,color:C.cream,fontSize:"12px",fontFamily:"inherit",boxSizing:"border-box",minHeight:"60px",resize:"vertical"},
  divider:{borderTop:`1px solid ${C.border}33`,margin:"12px 0"},
  link:{color:C.honey,textDecoration:"none",fontSize:"12px",cursor:"pointer"},
  tag:(c)=>({display:"inline-block",padding:"2px 7px",borderRadius:"4px",background:`${c}22`,color:c,fontSize:"10px",marginRight:"4px",marginBottom:"2px"}),
};

const Bar=({val,max=10,color=C.honey})=>(
  <div style={S.barWrap}><div style={{height:"100%",width:`${Math.min(100,(val/max)*100)}%`,background:color,borderRadius:"4px",transition:"width .4s"}}/></div>
);
const Field=({label,children})=>(<div style={{marginBottom:"9px"}}><div style={S.label}>{label}</div>{children}</div>);
const Sel=({value,onChange,options})=>(<select style={S.inp} value={value} onChange={e=>onChange(e.target.value)}>{options.map(o=><option key={o} value={o}>{o}</option>)}</select>);

const TABS=[
  ["dashboard","🏠 Home"],["hives","🐝 Hives"],["inspections","📋 Inspect"],
  ["harvest","🍯 Harvest"],["queens","👑 Queens"],["health","🔬 Health"],
  ["tasks","✅ Tasks"],["expenses","💰 Finance"],["calendar","📅 Calendar"],
  ["research","📚 Research"],["suppliers","🛒 Suppliers"],["startup","🚀 Startup"],
  ["diy","🪵 Build a Hive"],["guide","📖 Guide"],
];

export default function BeesMasterPro() {
  const [tab,setTab]=useState("dashboard");
  const [hives,setHives]=useState(DEMO_HIVES);
  const [inspections,setInspections]=useState(DEMO_INSPECTIONS);
  const [harvests,setHarvests]=useState(DEMO_HARVESTS);
  const [expenses,setExpenses]=useState(DEMO_EXPENSES);
  const [tasks,setTasks]=useState(DEMO_TASKS);
  const [queens,setQueens]=useState(DEMO_QUEENS);
  const [modal,setModal]=useState(null);
  const [detailHive,setDetailHive]=useState(null);
  const [researchFilter,setResearchFilter]=useState("All");
  const [supplierRegion,setSupplierRegion]=useState("All");
  const [startupLevel,setStartupLevel]=useState("hobbyist");
  const [expandedDiy,setExpandedDiy]=useState(null);
  const [expandedArticle,setExpandedArticle]=useState(null);

  const blankHive={name:"",location:"",type:"Langstroth",color:"#FFD700",notes:""};
  const blankInsp={hiveId:"",date:today,season:"Spring",weather:"Sunny",tempC:18,health:"Good",queen:"Present & Laying Well",queenColor:"",temperament:"Calm",brood:7,honey:7,pollen:6,population:7,disease:"None Detected",treatment:"None",treatmentDose:"",withdrawalDays:0,supers:0,frameCount:10,feedType:"None",feedAmount:0,swarmCells:false,swarmRisk:"Low",notes:"",varroa:0,varroaMethod:"Alcohol Wash",weight:""};
  const blankHarvest={hiveId:"",date:today,frames:4,weight:8,honeyType:"Wildflower",moisture:17.5,extracted:"Radial Extractor",jarCount:0,notes:""};
  const blankExpense={date:today,category:"Equipment",item:"",cost:"",notes:""};
  const blankTask={hiveId:"",task:"",due:today,priority:"Medium"};
  const blankQueen={hiveId:"",introduced:today,breed:"Italian",marked:false,markColor:"",status:"Active",notes:""};

  const [fHive,setFHive]=useState(blankHive);
  const [fInsp,setFInsp]=useState(blankInsp);
  const [fHarvest,setFHarvest]=useState(blankHarvest);
  const [fExpense,setFExpense]=useState(blankExpense);
  const [fTask,setFTask]=useState(blankTask);
  const [fQueen,setFQueen]=useState(blankQueen);

  const openM=(m)=>{
    if(m==="hive")setFHive(blankHive);
    if(m==="inspection")setFInsp({...blankInsp,hiveId:detailHive?.id||""});
    if(m==="harvest")setFHarvest({...blankHarvest,hiveId:detailHive?.id||""});
    if(m==="expense")setFExpense(blankExpense);
    if(m==="task")setFTask({...blankTask,hiveId:detailHive?.id||""});
    if(m==="queen")setFQueen({...blankQueen,hiveId:detailHive?.id||""});
    setModal(m);
  };
  const saveHive=()=>{if(!fHive.name.trim())return;setHives(h=>[...h,{...fHive,id:Date.now(),added:today}]);setModal(null);};
  const saveInsp=()=>{if(!fInsp.hiveId)return;setInspections(i=>[...i,{...fInsp,id:Date.now(),hiveId:parseInt(fInsp.hiveId)}]);setModal(null);};
  const saveHarvest=()=>{if(!fHarvest.hiveId)return;setHarvests(h=>[...h,{...fHarvest,id:Date.now(),hiveId:parseInt(fHarvest.hiveId)}]);setModal(null);};
  const saveExpense=()=>{if(!fExpense.item.trim())return;setExpenses(e=>[...e,{...fExpense,id:Date.now()}]);setModal(null);};
  const saveTask=()=>{if(!fTask.task.trim())return;setTasks(t=>[...t,{...fTask,id:Date.now(),done:false,hiveId:fTask.hiveId?parseInt(fTask.hiveId):null}]);setModal(null);};
  const saveQueen=()=>{if(!fQueen.hiveId)return;setQueens(q=>[...q,{...fQueen,id:Date.now(),hiveId:parseInt(fQueen.hiveId)}]);setModal(null);};
  const toggleTask=(id)=>setTasks(t=>t.map(x=>x.id===id?{...x,done:!x.done}:x));

  const lastInsp=(hid)=>[...inspections].filter(i=>i.hiveId===hid).sort((a,b)=>new Date(b.date)-new Date(a.date))[0];
  const hiveInsps=(hid)=>[...inspections].filter(i=>i.hiveId===hid).sort((a,b)=>new Date(b.date)-new Date(a.date));
  const hiveHarvs=(hid)=>[...harvests].filter(h=>h.hiveId===hid).sort((a,b)=>new Date(b.date)-new Date(a.date));
  const hiveQueen=(hid)=>[...queens].filter(q=>q.hiveId===hid).sort((a,b)=>new Date(b.introduced)-new Date(a.introduced))[0];

  const totalHoney=harvests.reduce((a,h)=>a+Number(h.weight),0);
  const totalRev=harvests.reduce((a,h)=>a+Number(h.jarCount)*6.5,0);
  const totalExp=expenses.reduce((a,e)=>a+Number(e.cost),0);
  const overdue=tasks.filter(t=>!t.done&&daysDiff(t.due)<0).length;
  const dueSoon=tasks.filter(t=>!t.done&&daysDiff(t.due)<=3&&daysDiff(t.due)>=0).length;

  // ── RESEARCH PAGE ──────────────────────────────────────────────────────
  const Research=()=>{
    const cats=["All",...new Set(RESEARCH_ARTICLES.map(a=>a.category))];
    const filtered=researchFilter==="All"?RESEARCH_ARTICLES:RESEARCH_ARTICLES.filter(a=>a.category===researchFilter);
    return (
      <div style={S.page}>
        <div style={S.h1}>📚 Research Library</div>
        <div style={{...S.card,background:`${C.purple}0A`,border:`1px solid ${C.purple}33`}}>
          <div style={{fontSize:"13px",color:C.cream,lineHeight:"1.7"}}>
            This library compiles the latest peer-reviewed scientific research, journal recommendations and academic resources relevant to every aspect of beekeeping — from colony health and disease management to technology, sustainability and innovation. All linked articles are open access or freely available online.
          </div>
        </div>
        <div style={{display:"flex",gap:"6px",flexWrap:"wrap",marginBottom:"14px"}}>
          {cats.map(c=><button key={c} style={{...S.btn(researchFilter===c?"primary":""),fontSize:"11px",padding:"5px 10px"}} onClick={()=>setResearchFilter(c)}>{c}</button>)}
        </div>
        {filtered.map(a=>(
          <div key={a.id} style={{...S.card,borderLeft:`4px solid ${a.color}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"8px"}}>
              <div style={{flex:1}}>
                <div style={S.tag(a.color)}>{a.category}</div>
                <div style={{color:C.gold,fontWeight:"bold",fontSize:"14px",marginTop:"4px"}}>{a.title}</div>
                <div style={{color:C.muted,fontSize:"11px",marginTop:"2px"}}>{a.authors} · {a.journal} · {a.year}</div>
              </div>
              <div style={{display:"flex",gap:"6px",flexShrink:0}}>
                <span style={S.badge(C.green)}>{a.access}</span>
                <button style={{...S.btn(""),fontSize:"11px",padding:"4px 10px"}} onClick={()=>setExpandedArticle(expandedArticle===a.id?null:a.id)}>
                  {expandedArticle===a.id?"▲ Less":"▼ More"}
                </button>
              </div>
            </div>
            <div style={{marginTop:"8px",fontSize:"12px",color:`${C.cream}CC`}}>{a.summary}</div>
            {expandedArticle===a.id && (
              <div style={{marginTop:"10px"}}>
                <div style={S.h3}>🔑 Key Findings</div>
                {a.keyFindings.map((f,i)=>(
                  <div key={i} style={{display:"flex",gap:"8px",marginBottom:"5px",fontSize:"12px",color:C.cream}}>
                    <span style={{color:a.color,flexShrink:0}}>▶</span><span>{f}</span>
                  </div>
                ))}
                <div style={{marginTop:"10px"}}>
                  <a href={a.url} target="_blank" rel="noopener noreferrer" style={{...S.link,background:`${a.color}22`,padding:"6px 12px",borderRadius:"6px",border:`1px solid ${a.color}44`,fontWeight:"bold"}}>
                    🔗 Read Full Article →
                  </a>
                </div>
                {a.doi && <div style={{marginTop:"6px",fontSize:"10px",color:C.muted}}>DOI / Reference: {a.doi}</div>}
              </div>
            )}
          </div>
        ))}
        <div style={{...S.card,marginTop:"4px"}}>
          <div style={S.h2}>📰 Key Journals to Follow</div>
          {[
            ["Journal of Apicultural Research","tandfonline.com/journals/tjar20","World's leading refereed bee science journal — covers all aspects of apiculture"],
            ["Insects (MDPI)","mdpi.com/journal/insects","Open-access — large volume of varroa, disease and precision beekeeping research"],
            ["Frontiers in Animal Science","frontiersin.org","Open-access research including beekeeping sustainability and management"],
            ["American Bee Journal","americanbeejournal.com","Oldest beekeeping publication in the US — practical & scientific mix"],
            ["Bee World (IBRA)","tandfonline.com/journals/tbee20","International Bee Research Association — global bee science"],
          ].map(([j,url,desc])=>(
            <div key={j} style={{...S.card,padding:"10px 12px",marginBottom:"8px"}}>
              <div style={{fontWeight:"bold",color:C.gold,fontSize:"13px"}}>{j}</div>
              <div style={{fontSize:"11px",color:C.muted,marginTop:"2px"}}>{desc}</div>
              <a href={`https://${url}`} target="_blank" rel="noopener noreferrer" style={{...S.link,marginTop:"4px",display:"block"}}>🔗 {url}</a>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ── SUPPLIERS PAGE ─────────────────────────────────────────────────────
  const Suppliers=()=>{
    const regions=["All","UK","US","International"];
    const filtered=supplierRegion==="All"?SUPPLIERS:SUPPLIERS.filter(s=>s.region===supplierRegion);
    return (
      <div style={S.page}>
        <div style={S.h1}>🛒 Equipment Suppliers</div>
        <div style={{...S.card,background:`${C.teal}0A`,border:`1px solid ${C.teal}33`}}>
          <div style={{fontSize:"13px",color:C.cream,lineHeight:"1.7"}}>
            Vetted suppliers of beekeeping equipment, live bees, protective clothing and processing machinery. Always compare prices and read reviews before ordering. Where possible, support local beekeeping associations and suppliers.
          </div>
        </div>
        <div style={{display:"flex",gap:"6px",marginBottom:"14px",flexWrap:"wrap"}}>
          {regions.map(r=><button key={r} style={{...S.btn(supplierRegion===r?"primary":""),fontSize:"11px",padding:"5px 10px"}} onClick={()=>setSupplierRegion(r)}>{r}</button>)}
        </div>
        {filtered.map(s=>(
          <div key={s.id} style={{...S.card,borderLeft:`4px solid ${C.honey}`}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",flexWrap:"wrap",gap:"8px"}}>
              <div style={{flex:1}}>
                <div style={{display:"flex",gap:"6px",flexWrap:"wrap",marginBottom:"4px"}}>
                  <span style={S.tag(C.muted)}>{s.region}</span>
                  <span style={S.tag(C.blue)}>{s.type}</span>
                  {s.beginner&&<span style={S.tag(C.green)}>✓ Beginner Friendly</span>}
                </div>
                <div style={{color:C.gold,fontWeight:"bold",fontSize:"15px"}}>{s.name}</div>
                <div style={{fontSize:"11px",color:C.amber,marginTop:"1px"}}>Speciality: {s.speciality} · Price: {s.priceRange}</div>
              </div>
              <div style={{display:"flex",gap:"4px",alignItems:"center"}}>
                {"⭐".repeat(s.rating)}
              </div>
            </div>
            <div style={{marginTop:"8px",fontSize:"12px",color:`${C.cream}CC`,lineHeight:"1.6"}}>{s.description}</div>
            <div style={{marginTop:"8px"}}>
              <a href={s.url} target="_blank" rel="noopener noreferrer" style={{...S.link,background:`${C.honey}18`,padding:"5px 12px",borderRadius:"6px",border:`1px solid ${C.honey}44`,fontWeight:"bold"}}>
                🔗 Visit {s.name} →
              </a>
            </div>
          </div>
        ))}
        <div style={S.card}>
          <div style={S.h2}>💡 Buying Tips</div>
          {[
            ["Join your local beekeeping association first","Many sell second-hand equipment and can give advice on local suppliers. BBKA (UK), your state association (US)."],
            ["Buy new hive boxes, used is risky","Second-hand boxes may carry disease spores (especially AFB). New boxes are worth the investment."],
            ["Start with one hive type and stick to it","Mixing Langstroth and National sizes creates compatibility problems. Choose one system."],
            ["Cedar over pine for hives","Costs more upfront but lasts 15–20 years vs 5–8 years for pine. Better insulation too."],
            ["Don't buy the cheapest suit","A sting through a poor veil is a miserable experience. Invest in a decent full suit with round veil."],
            ["Get bees from a local beekeeper","Local bees are adapted to your climate and forage. Avoid imported packages where possible."],
          ].map(([title,desc])=>(
            <div key={title} style={{borderLeft:`3px solid ${C.honey}`,paddingLeft:"10px",marginBottom:"10px"}}>
              <div style={{color:C.honey,fontWeight:"bold",fontSize:"13px"}}>{title}</div>
              <div style={{fontSize:"12px",color:C.muted,marginTop:"2px"}}>{desc}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ── STARTUP PAGE ──────────────────────────────────────────────────────
  const Startup=()=>{
    const levels=["hobbyist","smallComm","commercial"];
    const g=STARTUP_GUIDE[startupLevel];
    return (
      <div style={S.page}>
        <div style={S.h1}>🚀 Beekeeping Startup Guide</div>
        <div style={{...S.card,background:`${C.amber}0A`,border:`1px solid ${C.amber}33`}}>
          <div style={{fontSize:"13px",color:C.cream,lineHeight:"1.7"}}>
            Beekeeping can be a profitable venture at any scale. <strong style={{color:C.honey}}>The global bee industry is projected to reach $10.3 billion by 2025 growing at 4.8% annually.</strong> Raw honey commands premium prices and organic certification can add 40% to product value. Below is a complete financial and operational guide for each stage of growth.
          </div>
        </div>
        <div style={{display:"flex",gap:"6px",marginBottom:"14px",flexWrap:"wrap"}}>
          {levels.map(l=>{const g2=STARTUP_GUIDE[l];return(
            <button key={l} style={{...S.btn(startupLevel===l?"primary":""),fontSize:"11px",padding:"6px 12px",borderColor:g2.color}} onClick={()=>setStartupLevel(l)}>
              {g2.icon} {g2.label}
            </button>
          );})}
        </div>

        <div style={{...S.card,borderTop:`3px solid ${g.color}`}}>
          <div style={{fontSize:"18px",color:g.color,fontWeight:"bold",marginBottom:"8px"}}>{g.icon} {g.label}</div>
          <div style={S.grid2}>
            {[["💰 Startup Cost",g.startupCost],["📆 Annual Running",g.annualCost],["🍯 Expected Yield",g.expectedYield],["⏰ Time Commitment",g.timeCommitment]].map(([l,v])=>(
              <div key={l} style={S.stat}><div style={{fontSize:"11px",color:C.muted,marginBottom:"4px"}}>{l}</div><div style={{fontSize:"13px",color:C.cream,fontWeight:"bold"}}>{v}</div></div>
            ))}
          </div>
        </div>

        <div style={S.h2}>🛒 Equipment Checklist & Estimated Costs</div>
        {g.items.map((item,i)=>(
          <div key={i} style={{...S.card,padding:"10px 14px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:"8px"}}>
            <div style={{fontSize:"13px",color:C.cream}}>✓ {item.item}</div>
            <span style={S.badge(g.color)}>{item.cost}</span>
          </div>
        ))}

        <div style={{...S.h2,marginTop:"12px"}}>📋 Step-by-Step: How to Start</div>
        {g.steps.map((step,i)=>(
          <div key={i} style={{display:"flex",gap:"10px",marginBottom:"8px",alignItems:"flex-start"}}>
            <div style={{background:g.color,color:"#0D0700",borderRadius:"50%",width:"22px",height:"22px",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"11px",fontWeight:"bold",flexShrink:0}}>{i+1}</div>
            <div style={{fontSize:"13px",color:C.cream,lineHeight:"1.6"}}>{step}</div>
          </div>
        ))}

        <div style={{...S.h2,marginTop:"12px"}}>💰 Revenue Streams</div>
        <div style={S.grid2}>
          {g.revenueStreams.map((r,i)=>(
            <div key={i} style={{...S.card,padding:"10px",display:"flex",gap:"8px",alignItems:"flex-start"}}>
              <span style={{color:g.color,fontSize:"16px"}}>💛</span>
              <span style={{fontSize:"12px",color:C.cream}}>{r}</span>
            </div>
          ))}
        </div>

        <div style={{...S.card,marginTop:"8px",background:`${C.green}0A`,border:`1px solid ${C.green}33`}}>
          <div style={{...S.h2,color:C.green}}>📊 Market Facts (2025 Data)</div>
          <div style={S.grid2}>
            {[
              ["$10.3B","Global bee industry size 2025",""],
              ["4.8%","Annual industry growth rate",""],
              ["25%","Honey market growth since 2020",""],
              ["+40%","Premium from organic certification",""],
              ["15–25%","Net profit margins for managed apiaries",""],
              ["£5–£20","Typical price per jar (hobbyist to premium)",""],
            ].map(([v,l])=>(
              <div key={l} style={S.stat}>
                <div style={{...S.statNum,fontSize:"20px",color:C.green}}>{v}</div>
                <div style={S.statLabel}>{l}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={S.card}>
          <div style={S.h2}>⚖️ Legal Requirements (UK)</div>
          {[
            ["Register your hives","Register on BeeBase (National Bee Unit) — free, required by law in some areas. Allows inspectors to contact you about local disease outbreaks."],
            ["Food business registration","If selling honey, register as a food business with your local council — free and required. Done online in minutes."],
            ["Food hygiene certificate","Recommended for any food sales. Free Level 2 courses available online via RSPH or Highfield."],
            ["Labelling requirements","All honey sold must show: weight, producer name/address, country of origin, and best before date. No health claims without authorisation."],
            ["Insurance","BBKA membership includes public liability insurance. Essential before selling or allowing public access to your apiary."],
            ["Planning permission","Usually not required for beehives in gardens, but check with your local authority if in an urban or conservation area."],
          ].map(([t,d])=>(
            <div key={t} style={{borderLeft:`3px solid ${C.amber}`,paddingLeft:"10px",marginBottom:"10px"}}>
              <div style={{color:C.amber,fontWeight:"bold",fontSize:"12px"}}>{t}</div>
              <div style={{fontSize:"12px",color:C.muted,marginTop:"2px"}}>{d}</div>
            </div>
          ))}
        </div>

        <div style={S.card}>
          <div style={S.h2}>📚 Recommended Reading & Courses</div>
          {[
            ["Beekeeping for Beginners (Book)","goodreads.com/book/show/200634832","Covers hive building, colony management, honey harvesting and turning beekeeping into profit"],
            ["BBKA (British Beekeepers Association)","bbka.org.uk","Foundation certificate, training, insurance and apiary support across the UK"],
            ["Bee Informed Partnership (US)","beeinformed.org","Science-based best management practices for American beekeepers"],
            ["National Bee Unit (UK)","nationalbeeunit.com","Register hives, access inspection services, disease alerts and BeeBase records"],
            ["American Bee Journal","americanbeejournal.com","Oldest US beekeeping publication — practical guidance and market insights"],
          ].map(([title,url,desc])=>(
            <div key={title} style={{...S.card,padding:"10px 12px",marginBottom:"8px"}}>
              <div style={{fontWeight:"bold",color:C.gold,fontSize:"13px"}}>{title}</div>
              <div style={{fontSize:"11px",color:C.muted}}>{desc}</div>
              <a href={`https://${url}`} target="_blank" rel="noopener noreferrer" style={{...S.link,display:"block",marginTop:"3px"}}>🔗 {url}</a>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // ── DIY PAGE ──────────────────────────────────────────────────────────
  const Diy=()=>(
    <div style={S.page}>
      <div style={S.h1}>🪵 Build Your Own Beehive</div>
      <div style={{...S.card,background:`${C.amber}0A`,border:`1px solid ${C.amber}33`}}>
        <div style={{fontSize:"13px",color:C.cream,lineHeight:"1.7"}}>
          Building your own hive can save 50–70% on equipment costs and gives you deep understanding of the hive structure. A basic Langstroth takes 8–12 hours for a beginner. All plans and resources below are freely available online. Note: it's usually better to <strong style={{color:C.honey}}>buy frames and foundation</strong> rather than make them — precision matters for bee space.
        </div>
      </div>

      <div style={{...S.card,marginBottom:"12px"}}>
        <div style={S.h2}>⚖️ Build vs Buy — Should You DIY?</div>
        <div style={S.grid2}>
          <div>
            <div style={{color:C.green,fontWeight:"bold",fontSize:"13px",marginBottom:"6px"}}>✅ Build if...</div>
            {["You enjoy woodworking","You want to save £100–£200 per hive","You have the tools (table saw, miter saw)","You want to understand hive construction deeply","You're building multiple hives"].map((t,i)=>(<div key={i} style={{fontSize:"12px",color:C.cream,marginBottom:"3px"}}>• {t}</div>))}
          </div>
          <div>
            <div style={{color:C.red,fontWeight:"bold",fontSize:"13px",marginBottom:"6px"}}>❌ Buy if...</div>
            {["You're a complete beginner — learn bees first","You don't have woodworking tools","You want bees this season (no time to build)","You want guaranteed bee space precision","You prefer to spend time on beekeeping, not carpentry"].map((t,i)=>(<div key={i} style={{fontSize:"12px",color:C.cream,marginBottom:"3px"}}>• {t}</div>))}
          </div>
        </div>
      </div>

      {DIY_GUIDE.map(step=>(
        <div key={step.step} style={{...S.card,borderLeft:`4px solid ${C.amber}`}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",cursor:"pointer"}} onClick={()=>setExpandedDiy(expandedDiy===step.step?null:step.step)}>
            <div>
              <div style={{display:"flex",gap:"10px",alignItems:"center"}}>
                <div style={{background:C.amber,color:"#0D0700",borderRadius:"50%",width:"26px",height:"26px",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:"bold",fontSize:"13px",flexShrink:0}}>{step.step}</div>
                <div>
                  <div style={{color:C.gold,fontWeight:"bold",fontSize:"14px"}}>{step.icon} {step.title}</div>
                  <div style={{fontSize:"11px",color:C.muted}}>{step.time}</div>
                </div>
              </div>
            </div>
            <span style={{color:C.honey,fontSize:"16px"}}>{expandedDiy===step.step?"▲":"▼"}</span>
          </div>
          {expandedDiy===step.step && (
            <div style={{marginTop:"12px"}}>
              <div style={{fontSize:"13px",color:C.cream,lineHeight:"1.7",marginBottom:"12px"}}>{step.content}</div>
              <div style={S.h3}>🔗 Free Resources & Plans</div>
              {step.resources.map((r,i)=>(
                <div key={i} style={{marginBottom:"6px"}}>
                  <a href={r.url} target="_blank" rel="noopener noreferrer" style={{...S.link,display:"flex",alignItems:"center",gap:"6px"}}>
                    <span>📄</span><span>{r.label}</span>
                  </a>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      <div style={S.card}>
        <div style={S.h2}>🔨 Essential Tools for Hive Building</div>
        <div style={S.grid2}>
          {[["Table Saw","Ripping boards to width — most important tool"],["Miter Saw","Cutting pieces to length accurately"],["Jigsaw","Cutting entrance notches and curves"],["Drill & Screwdriver","Assembly"],["Wood Glue","Weatherproof exterior grade (Titebond III)"],["Clamps","Holding pieces while glue dries"],["Sandpaper","Finishing — 80 and 120 grit"],["Measuring Tape","Precision is critical for bee space (8–9mm)"]].map(([t,d])=>(
            <div key={t} style={{...S.card,padding:"9px 12px"}}>
              <div style={{color:C.amber,fontWeight:"bold",fontSize:"12px"}}>🔧 {t}</div>
              <div style={{fontSize:"11px",color:C.muted,marginTop:"2px"}}>{d}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{...S.card,background:`${C.green}0A`,border:`1px solid ${C.green}33`}}>
        <div style={{...S.h2,color:C.green}}>🌲 Best Wood for Beehives</div>
        {[
          ["Western Red Cedar ⭐⭐⭐⭐⭐","Naturally rot-resistant, light, excellent insulation. Best long-term choice. Lasts 15–20+ years. More expensive but worth it."],
          ["Pine ⭐⭐⭐","Widely available, cheap, easy to work. Needs regular painting. Lasts 5–10 years with care."],
          ["Plywood (exterior grade) ⭐⭐⭐","Good for flat panels (floors, roofs). Not suitable for boxes — swells and warps."],
          ["Tulip Poplar ⭐⭐⭐⭐","Popular in the US. Lightweight, stable, takes paint well. Good all-round choice."],
        ].map(([t,d])=>(
          <div key={t} style={{borderLeft:`3px solid ${C.green}`,paddingLeft:"10px",marginBottom:"10px"}}>
            <div style={{color:C.green,fontWeight:"bold",fontSize:"12px"}}>{t}</div>
            <div style={{fontSize:"12px",color:C.muted,marginTop:"2px"}}>{d}</div>
          </div>
        ))}
      </div>
    </div>
  );

  // ── DASHBOARD ──────────────────────────────────────────────────────────
  const Dashboard=()=>{
    const alerts=[];
    hives.forEach(h=>{
      const l=lastInsp(h.id);
      if(!l) alerts.push({type:"warn",msg:`${h.name}: No inspections recorded`});
      else {
        const days=Math.round((new Date()-new Date(l.date))/86400000);
        if(days>14) alerts.push({type:"warn",msg:`${h.name}: Last inspection ${days} days ago`});
        if(l.varroa>3) alerts.push({type:"danger",msg:`${h.name}: High varroa (${l.varroa}) — treat now`});
        if(l.swarmCells) alerts.push({type:"danger",msg:`${h.name}: Swarm cells detected!`});
        if(l.health==="Critical"||l.health==="Poor") alerts.push({type:"danger",msg:`${h.name}: Health ${l.health} — urgent`});
        if(l.queen==="Queenless - Needs Requeening") alerts.push({type:"danger",msg:`${h.name}: QUEENLESS`});
        if(l.honey<=3) alerts.push({type:"warn",msg:`${h.name}: Low honey stores — consider feeding`});
      }
    });
    if(overdue>0) alerts.push({type:"danger",msg:`${overdue} overdue task${overdue>1?"s":""}`});
    if(dueSoon>0) alerts.push({type:"warn",msg:`${dueSoon} task${dueSoon>1?"s":""} due within 3 days`});
    return (
      <div style={S.page}>
        <div style={S.h1}>🐝 BeesMaster Pro — Apiary Dashboard</div>
        {alerts.length>0&&<div style={{marginBottom:"14px"}}>
          <div style={{...S.h2,color:C.red}}>⚠️ Active Alerts</div>
          {alerts.map((a,i)=><div key={i} style={S.alert(a.type==="danger"?C.red:C.amber)}>{a.type==="danger"?"🚨":"⚠️"} {a.msg}</div>)}
        </div>}
        <div style={S.grid4}>
          {[[hives.length,"Hives",C.gold,"🏠"],[inspections.length,"Inspections",C.honey,"📋"],[`${totalHoney.toFixed(1)}kg`,"Honey",C.amber,"🍯"],[tasks.filter(t=>!t.done).length,"Tasks",C.blue,"✅"]].map(([v,l,c,e])=>(
            <div key={l} style={S.stat}><div style={{fontSize:"18px"}}>{e}</div><div style={{...S.statNum,color:c,fontSize:"20px"}}>{v}</div><div style={S.statLabel}>{l}</div></div>
          ))}
        </div>
        <div style={{...S.h2,marginTop:"14px"}}>🏠 Hive Status</div>
        {hives.map(h=>{
          const l=lastInsp(h.id);
          const days=l?Math.round((new Date()-new Date(l.date))/86400000):null;
          return (
            <div key={h.id} style={{...S.card,cursor:"pointer",borderLeft:`4px solid ${h.color||C.honey}`}} onClick={()=>{setDetailHive(h);setTab("hivedetail");}}>
              <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:"6px"}}>
                <div><span style={{fontSize:"15px",color:C.gold,fontWeight:"bold"}}>🏠 {h.name}</span><span style={{fontSize:"11px",color:C.muted,marginLeft:"8px"}}>📍 {h.location}</span></div>
                <div style={{display:"flex",gap:"5px"}}>
                  {l&&<span style={S.badge(hc(l.health))}>{l.health}</span>}
                  {days!==null&&<span style={S.badge(days>14?C.red:days>7?C.amber:C.green)}>{days}d ago</span>}
                </div>
              </div>
              {l&&<div style={{display:"flex",gap:"12px",flexWrap:"wrap",fontSize:"11px",color:C.muted,marginTop:"8px"}}>
                <span>🍯 {l.honey}/10</span><span>🐣 {l.brood}/10</span><span>👥 {l.population}/10</span>
                <span style={{color:vc(l.varroa)}}>🔬 V:{l.varroa}</span><span>😊 {l.temperament}</span>
              </div>}
              {!l&&<div style={{color:C.muted,fontSize:"12px",marginTop:"6px"}}>No inspections yet</div>}
            </div>
          );
        })}
        <button style={S.btn("primary")} onClick={()=>openM("hive")}>+ Add Hive</button>
        <div style={{...S.h2,marginTop:"14px"}}>✅ Open Tasks</div>
        {tasks.filter(t=>!t.done).slice(0,4).map(t=>{
          const d=daysDiff(t.due);
          const hive=hives.find(h=>h.id===t.hiveId);
          return (
            <div key={t.id} style={{...S.card,display:"flex",alignItems:"center",gap:"10px",padding:"10px 14px"}}>
              <input type="checkbox" onChange={()=>toggleTask(t.id)} style={{accentColor:C.honey,width:"15px",height:"15px",cursor:"pointer"}}/>
              <div style={{flex:1}}>
                <div style={{fontSize:"12px",color:C.cream}}>{t.task}</div>
                <div style={{fontSize:"10px",color:C.muted}}>{hive?`${hive.name} · `:""}{t.due} {d<0?`(${Math.abs(d)}d overdue)`:d===0?"(Today!)":d<=3?`(${d}d)`:""}</div>
              </div>
              <span style={S.badge(pc(t.priority))}>{t.priority}</span>
            </div>
          );
        })}
      </div>
    );
  };

  // ── HIVE DETAIL ────────────────────────────────────────────────────────
  const HiveDetail=()=>{
    if(!detailHive)return null;
    const h=detailHive;
    const insps=hiveInsps(h.id);
    const harvs=hiveHarvs(h.id);
    const q=hiveQueen(h.id);
    return (
      <div style={S.page}>
        <button style={{...S.btn(""),marginBottom:"12px",fontSize:"11px"}} onClick={()=>setTab("hives")}>← Back</button>
        <div style={{...S.card,borderLeft:`5px solid ${h.color||C.honey}`}}>
          <div style={{fontSize:"18px",color:C.gold,fontWeight:"bold"}}>🏠 {h.name}</div>
          <div style={{color:C.muted,fontSize:"12px",marginTop:"3px"}}>📍 {h.location} · {h.type} · Added {h.added}</div>
          {h.notes&&<div style={{marginTop:"6px",fontSize:"12px",color:C.cream,fontStyle:"italic"}}>"{h.notes}"</div>}
        </div>
        {q&&<div style={S.card}>
          <div style={S.h2}>👑 Current Queen</div>
          <div style={S.grid2}>
            {[["Breed",q.breed],["Introduced",q.introduced],["Status",q.status],["Mark",q.marked?q.markColor:"Unmarked"]].map(([l,v])=>(
              <div key={l}><div style={S.label}>{l}</div><div style={{...S.val,fontSize:"13px"}}>{v}</div></div>
            ))}
          </div>
        </div>}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"10px"}}>
          <div style={S.h2}>📋 Inspections ({insps.length})</div>
          <div style={{display:"flex",gap:"6px"}}>
            <button style={{...S.btn("primary"),fontSize:"11px"}} onClick={()=>openM("inspection")}>+ Inspection</button>
            <button style={{...S.btn(""),fontSize:"11px"}} onClick={()=>openM("harvest")}>+ Harvest</button>
            <button style={{...S.btn(""),fontSize:"11px"}} onClick={()=>openM("queen")}>+ Queen</button>
          </div>
        </div>
        {insps.map(ins=>(
          <div key={ins.id} style={S.card}>
            <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:"6px",marginBottom:"8px"}}>
              <span style={{color:C.gold,fontWeight:"bold"}}>📅 {ins.date} · {ins.weather} {ins.tempC}°C</span>
              <div style={{display:"flex",gap:"5px"}}><span style={S.badge(hc(ins.health))}>{ins.health}</span>{ins.swarmCells&&<span style={S.badge(C.red)}>⚠️ Swarm</span>}</div>
            </div>
            <div style={S.row}>
              {[["Honey",ins.honey,C.honey],["Brood",ins.brood,C.green],["Pop",ins.population,C.blue],["Pollen",ins.pollen,C.amber]].map(([l,v,c])=>(
                <div key={l} style={{...S.col,minWidth:"80px"}}><div style={S.label}>{l} {v}/10</div><Bar val={v} color={c}/></div>
              ))}
            </div>
            <div style={{fontSize:"11px",color:C.muted,display:"flex",gap:"10px",flexWrap:"wrap"}}>
              <span>👑 {ins.queen.split(" ")[0]}</span>
              <span style={{color:vc(ins.varroa)}}>🔬 {ins.varroa} ({ins.varroaMethod})</span>
              {ins.weight&&<span>⚖️ {ins.weight}kg</span>}
              {ins.treatment!=="None"&&<span style={{color:C.amber}}>💊 {ins.treatment.split(" ")[0]}</span>}
              {ins.disease!=="None Detected"&&<span style={{color:C.red}}>🦠 {ins.disease.split(" ")[0]}</span>}
            </div>
            {ins.notes&&<div style={{marginTop:"6px",fontSize:"12px",fontStyle:"italic",color:`${C.cream}99`}}>"{ins.notes}"</div>}
          </div>
        ))}
        {harvs.length>0&&<><div style={S.h2}>🍯 Harvests</div>
        {harvs.map(hv=>(
          <div key={hv.id} style={{...S.card,padding:"10px 14px"}}>
            <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:"6px"}}>
              <span style={{color:C.gold,fontWeight:"bold"}}>🍯 {hv.honeyType} · {hv.date}</span>
              <span style={S.badge(C.amber)}>{hv.weight}kg · {hv.jarCount} jars</span>
            </div>
            <div style={{fontSize:"11px",color:C.muted,marginTop:"4px"}}>{hv.frames} frames · Moisture {hv.moisture}% · {hv.extracted}</div>
          </div>
        ))}</>}
      </div>
    );
  };

  // ── OTHER PAGES (compact) ─────────────────────────────────────────────
  const HivesList=()=>(
    <div style={S.page}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"12px"}}>
        <div style={S.h1}>🐝 All Hives</div>
        <button style={S.btn("primary")} onClick={()=>openM("hive")}>+ Add Hive</button>
      </div>
      {hives.map(h=>{const l=lastInsp(h.id);const q=hiveQueen(h.id);return(
        <div key={h.id} style={{...S.card,cursor:"pointer",borderLeft:`5px solid ${h.color||C.honey}`}} onClick={()=>{setDetailHive(h);setTab("hivedetail");}}>
          <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:"6px"}}>
            <div><div style={{fontSize:"16px",color:C.gold,fontWeight:"bold"}}>🏠 {h.name}</div><div style={{fontSize:"11px",color:C.muted}}>📍 {h.location} · {h.type}</div></div>
            {l&&<span style={S.badge(hc(l.health))}>{l.health}</span>}
          </div>
          <div style={{fontSize:"11px",color:C.muted,marginTop:"8px",display:"flex",gap:"12px",flexWrap:"wrap"}}>
            {q&&<span>👑 {q.breed}</span>}
            {l&&<><span>📅 {l.date}</span><span style={{color:vc(l.varroa)}}>🔬 V:{l.varroa}</span><span>🍯 {l.honey}/10</span></>}
            {!l&&<span style={{color:C.red}}>⚠️ No inspections</span>}
          </div>
        </div>
      );})}
    </div>
  );

  const Inspections=()=>(
    <div style={S.page}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"12px"}}>
        <div style={S.h1}>📋 All Inspections</div>
        <button style={S.btn("primary")} onClick={()=>openM("inspection")}>+ Log Inspection</button>
      </div>
      {[...inspections].sort((a,b)=>new Date(b.date)-new Date(a.date)).map(ins=>{
        const hive=hives.find(h=>h.id===ins.hiveId);
        return (
          <div key={ins.id} style={S.card}>
            <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:"6px",marginBottom:"6px"}}>
              <div><span style={{color:C.gold,fontWeight:"bold"}}>🏠 {hive?.name||"?"}</span><span style={{color:C.muted,fontSize:"11px",marginLeft:"8px"}}>📅 {ins.date}</span></div>
              <div style={{display:"flex",gap:"4px"}}><span style={S.badge(hc(ins.health))}>{ins.health}</span>{ins.swarmCells&&<span style={S.badge(C.red)}>⚠️</span>}</div>
            </div>
            <div style={{fontSize:"11px",color:C.muted,display:"flex",gap:"10px",flexWrap:"wrap"}}>
              <span>🍯{ins.honey}</span><span>🐣{ins.brood}</span><span>👥{ins.population}</span>
              <span style={{color:vc(ins.varroa)}}>🔬{ins.varroa}</span><span>😊{ins.temperament}</span>
              {ins.treatment!=="None"&&<span style={{color:C.amber}}>💊{ins.treatment.split(" ")[0]}</span>}
            </div>
            {ins.notes&&<div style={{marginTop:"5px",fontSize:"11px",fontStyle:"italic",color:`${C.cream}88`}}>"{ins.notes}"</div>}
          </div>
        );
      })}
    </div>
  );

  const Harvest=()=>(
    <div style={S.page}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"12px"}}>
        <div style={S.h1}>🍯 Harvest Records</div>
        <button style={S.btn("primary")} onClick={()=>openM("harvest")}>+ Log Harvest</button>
      </div>
      <div style={S.grid4}>
        {[[`${totalHoney.toFixed(1)}kg`,"Total Honey",C.gold],[harvests.reduce((a,h)=>a+h.jarCount,0),"Total Jars",C.amber],[`£${(totalHoney*6.5).toFixed(0)}`,"Est. Revenue",C.green],[harvests.length,"Harvests",C.honey]].map(([v,l,c])=>(
          <div key={l} style={S.stat}><div style={{...S.statNum,color:c,fontSize:"18px"}}>{v}</div><div style={S.statLabel}>{l}</div></div>
        ))}
      </div>
      {[...harvests].sort((a,b)=>new Date(b.date)-new Date(a.date)).map(hv=>{
        const hive=hives.find(h=>h.id===hv.hiveId);
        return (
          <div key={hv.id} style={S.card}>
            <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:"6px"}}>
              <div><span style={{color:C.gold,fontWeight:"bold"}}>🍯 {hv.honeyType}</span><span style={{color:C.muted,fontSize:"11px",marginLeft:"8px"}}>{hive?.name} · {hv.date}</span></div>
              <span style={S.badge(C.amber)}>{hv.weight}kg</span>
            </div>
            <div style={{fontSize:"11px",color:C.muted,marginTop:"5px",display:"flex",gap:"10px",flexWrap:"wrap"}}>
              <span>🖼️{hv.frames}f</span><span>💧{hv.moisture}%</span><span>🫙{hv.jarCount} jars</span><span style={{color:C.green}}>💰£{(hv.jarCount*6.5).toFixed(0)}</span>
            </div>
            {hv.notes&&<div style={{marginTop:"4px",fontSize:"11px",fontStyle:"italic",color:`${C.cream}88`}}>"{hv.notes}"</div>}
          </div>
        );
      })}
    </div>
  );

  const Queens=()=>(
    <div style={S.page}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"12px"}}>
        <div style={S.h1}>👑 Queen Records</div>
        <button style={S.btn("primary")} onClick={()=>openM("queen")}>+ Record Queen</button>
      </div>
      <div style={{...S.card,background:`${C.gold}0A`,border:`1px solid ${C.gold}33`,marginBottom:"12px"}}>
        <div style={S.h3}>Queen Colour Marking Guide</div>
        <div style={{display:"flex",gap:"8px",flexWrap:"wrap",fontSize:"12px"}}>
          {[["2021/2026","White"],["2022/2027","Yellow"],["2023/2028","Red"],["2024/2029","Green"],["2025/2030","Blue"]].map(([yr,c])=>(
            <div key={yr} style={{padding:"5px 10px",borderRadius:"6px",background:C.card,border:`1px solid ${C.border}33`,textAlign:"center"}}>
              <div style={{color:C.gold,fontWeight:"bold"}}>{c}</div><div style={{color:C.muted,fontSize:"10px"}}>{yr}</div>
            </div>
          ))}
        </div>
      </div>
      {queens.map(q=>{
        const hive=hives.find(h=>h.id===q.hiveId);
        const age=((new Date()-new Date(q.introduced))/(365.25*86400000)).toFixed(1);
        return (
          <div key={q.id} style={{...S.card,borderLeft:`4px solid ${C.gold}`}}>
            <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:"6px"}}>
              <div><div style={{color:C.gold,fontWeight:"bold"}}>👑 {hive?.name}</div><div style={{fontSize:"11px",color:C.muted}}>{q.breed} · {q.introduced} · Age: {age}yrs</div></div>
              <span style={S.badge(q.status==="Active"?C.green:C.red)}>{q.status}</span>
            </div>
            <div style={{fontSize:"11px",color:C.muted,marginTop:"6px",display:"flex",gap:"10px",flexWrap:"wrap"}}>
              <span>Mark: {q.marked?q.markColor:"Unmarked"}</span>
            </div>
            {Number(age)>2&&<div style={{...S.alert(C.amber),marginTop:"6px",padding:"6px 10px",fontSize:"11px"}}>⚠️ Over 2 years old — consider requeening</div>}
            {q.notes&&<div style={{fontSize:"11px",fontStyle:"italic",color:C.muted,marginTop:"4px"}}>"{q.notes}"</div>}
          </div>
        );
      })}
    </div>
  );

  const Health=()=>(
    <div style={S.page}>
      <div style={S.h1}>🔬 Health & Disease Monitor</div>
      <div style={{...S.card,background:`${C.red}0A`,border:`1px solid ${C.red}33`}}>
        <div style={{...S.h2,color:C.red}}>🔬 Varroa Status — All Hives</div>
        {hives.map(h=>{const l=lastInsp(h.id);if(!l)return <div key={h.id} style={{fontSize:"12px",color:C.muted,marginBottom:"6px"}}>🏠 {h.name}: No data</div>;
          return (<div key={h.id} style={{marginBottom:"10px"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:"3px",fontSize:"12px"}}>
              <span style={{color:C.cream}}>🏠 {h.name}</span>
              <span style={{color:vc(l.varroa),fontWeight:"bold"}}>{l.varroa}/100 {l.varroa>3?"🚨 TREAT":l.varroa>1?"⚡ Monitor":"✅"}</span>
            </div>
            <Bar val={l.varroa} max={10} color={vc(l.varroa)}/>
          </div>);
        })}
      </div>
      <div style={S.card}>
        <div style={S.h2}>🦠 Disease Reference</div>
        {[["American Foulbrood","Notifiable. Brown sunken cappings, foul smell. Burn equipment. Contact authorities immediately.",C.red],["Varroa","Most serious threat. Count every 4–6 weeks. Treat above 3/100 bees.",C.red],["Nosema","Dysentery symptoms. Feed Fumagilin-B in spring. Improve ventilation.",C.amber],["Chalkbrood","Mummified larvae. Improve ventilation. Replace old comb.",C.amber],["Small Hive Beetle","Trap adults, freeze frames. Strong colonies resist.",C.amber],["Wax Moth","Affects weak colonies. Freeze combs 48hrs.",C.muted]].map(([d,t,c])=>(
          <div key={d} style={{borderLeft:`3px solid ${c}`,paddingLeft:"10px",marginBottom:"10px"}}>
            <div style={{color:c,fontWeight:"bold",fontSize:"12px"}}>{d}</div>
            <div style={{fontSize:"11px",color:C.muted,marginTop:"2px"}}>{t}</div>
          </div>
        ))}
      </div>
    </div>
  );

  const Tasks=()=>{
    const open=tasks.filter(t=>!t.done).sort((a,b)=>new Date(a.due)-new Date(b.due));
    const done=tasks.filter(t=>t.done);
    return (
      <div style={S.page}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"12px"}}>
          <div style={S.h1}>✅ Task Manager</div>
          <button style={S.btn("primary")} onClick={()=>openM("task")}>+ Add Task</button>
        </div>
        <div style={S.grid4}>
          {[[open.length,"Open",C.honey],[overdue,"Overdue",C.red],[dueSoon,"Due Soon",C.amber],[done.length,"Done",C.green]].map(([v,l,c])=>(
            <div key={l} style={S.stat}><div style={{...S.statNum,color:c,fontSize:"20px"}}>{v}</div><div style={S.statLabel}>{l}</div></div>
          ))}
        </div>
        {open.map(t=>{const d=daysDiff(t.due);const hive=hives.find(h=>h.id===t.hiveId);return(
          <div key={t.id} style={{...S.card,display:"flex",gap:"10px",alignItems:"flex-start",borderLeft:`3px solid ${pc(t.priority)}`}}>
            <input type="checkbox" onChange={()=>toggleTask(t.id)} style={{accentColor:C.honey,width:"15px",height:"15px",cursor:"pointer",marginTop:"2px"}}/>
            <div style={{flex:1}}>
              <div style={{color:C.cream,fontSize:"12px",fontWeight:"bold"}}>{t.task}</div>
              <div style={{fontSize:"10px",color:C.muted,marginTop:"2px"}}>{hive?`${hive.name} · `:""}{t.due} <span style={{color:d<0?C.red:d<=3?C.amber:C.muted}}>{d<0?`${Math.abs(d)}d OVERDUE`:d===0?"TODAY":d<=3?`${d}d left`:""}</span></div>
            </div>
            <span style={S.badge(pc(t.priority))}>{t.priority}</span>
          </div>
        );})}
        {done.length>0&&<>{done.map(t=>(
          <div key={t.id} style={{...S.card,display:"flex",gap:"10px",alignItems:"center",opacity:0.5}}>
            <input type="checkbox" checked onChange={()=>toggleTask(t.id)} style={{accentColor:C.honey,width:"15px",height:"15px",cursor:"pointer"}}/>
            <div style={{textDecoration:"line-through",color:C.muted,fontSize:"12px"}}>{t.task}</div>
          </div>
        ))}</>}
      </div>
    );
  };

  const Expenses=()=>{
    const byCat={};expenses.forEach(e=>{byCat[e.category]=(byCat[e.category]||0)+Number(e.cost);});
    const profit=totalRev-totalExp;
    return (
      <div style={S.page}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:"12px"}}>
          <div style={S.h1}>💰 Financial Records</div>
          <button style={S.btn("primary")} onClick={()=>openM("expense")}>+ Expense</button>
        </div>
        <div style={S.grid4}>
          {[[fmt(totalRev),"Revenue",C.green],[fmt(totalExp),"Expenses",C.red],[fmt(profit),"Profit",profit>=0?C.green:C.red],[fmt(totalHoney>0?totalExp/totalHoney:0),"Cost/kg",C.amber]].map(([v,l,c])=>(
            <div key={l} style={S.stat}><div style={{...S.statNum,color:c,fontSize:"16px"}}>{v}</div><div style={S.statLabel}>{l}</div></div>
          ))}
        </div>
        {[...expenses].sort((a,b)=>new Date(b.date)-new Date(a.date)).map(e=>(
          <div key={e.id} style={{...S.card,display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:"6px",padding:"10px 14px"}}>
            <div><div style={{color:C.cream,fontSize:"12px",fontWeight:"bold"}}>{e.item}</div><div style={{fontSize:"10px",color:C.muted}}>{e.category} · {e.date}</div></div>
            <span style={S.badge(C.red)}>{fmt(e.cost)}</span>
          </div>
        ))}
      </div>
    );
  };

  const Calendar=()=>{
    const month=new Date().getMonth();
    const seasonal=[
      {m:[2,3,4],task:"Spring build-up: start 1:1 syrup feeding, check queen laying",icon:"🌸"},
      {m:[2,3,4],task:"Add supers as colony expands — don't let them run out of space",icon:"📦"},
      {m:[3,4,5],task:"Swarm season: inspect every 7 days, check for queen cells",icon:"🐝"},
      {m:[4,5,6],task:"Main honey flow — add supers generously, monitor space",icon:"🍯"},
      {m:[6,7],task:"Harvest summer honey — check moisture below 20%",icon:"🫙"},
      {m:[7,8],task:"Varroa treatment — treat after harvest with Apiguard or ApiVar",icon:"💊"},
      {m:[8,9],task:"Autumn feeding — switch to 2:1 syrup for winter stores",icon:"🍂"},
      {m:[9,10],task:"Reduce entrance, fit mouse guards, apply OA for winter varroa",icon:"🚪"},
      {m:[10,11,12,0,1],task:"Winter cluster — leave bees, check by hefting only",icon:"❄️"},
    ].filter(t=>t.m.includes(month));
    return (
      <div style={S.page}>
        <div style={S.h1}>📅 Beekeeping Calendar</div>
        <div style={{...S.card,background:`${C.green}0A`,border:`1px solid ${C.green}33`}}>
          <div style={{...S.h2,color:C.green}}>🌿 This Month — Seasonal Tasks</div>
          {seasonal.map((t,i)=>(
            <div key={i} style={{display:"flex",gap:"10px",marginBottom:"7px",alignItems:"flex-start"}}>
              <span style={{fontSize:"18px"}}>{t.icon}</span><div style={{fontSize:"12px",color:C.cream}}>{t.task}</div>
            </div>
          ))}
        </div>
        <div style={S.card}>
          <div style={S.h2}>📆 Annual Overview</div>
          {[["Jan–Feb","Winter. Leave bees. Heft hives. Emergency fondant if light."],["Mar","First inspections on warm days (>10°C). Spring feeding. Check queen."],["Apr–May","Swarm prevention. Add supers. Weekly inspections. Peak growth."],["Jun","Main nectar flow. Monitor space. Consider splits."],["Jul","Harvest summer honey. Begin varroa treatment immediately after."],["Aug","Autumn feeding (2:1). Prepare winter stores."],["Sep–Oct","Unite weak colonies. OA treatment. Mouse guards on."],["Nov–Dec","Equipment check. Order next year's supplies. Leave bees alone."]].map(([period,desc])=>(
            <div key={period} style={{marginBottom:"8px",paddingBottom:"8px",borderBottom:`1px solid ${C.border}22`}}>
              <div style={{color:C.honey,fontWeight:"bold",fontSize:"12px"}}>{period}</div>
              <div style={{fontSize:"11px",color:C.muted,marginTop:"2px"}}>{desc}</div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const Guide=()=>(
    <div style={S.page}>
      <div style={S.h1}>📖 Beekeeper's Reference Guide</div>
      {[
        {title:"🔍 Spotting the Queen",color:C.gold,content:["Look for the longest bee — elongated abdomen","Bees form a 'retinue' around her, facing inwards","She moves slowly and deliberately","Look on frames with fresh eggs — she'll be nearby","Mark her with a paint pen using the correct year colour"]},
        {title:"🥚 Reading Brood",color:C.green,content:["Eggs: tiny upright white grains — queen present 3 days ago","Larvae: c-shaped white grubs in cells — 3–8 days","Capped worker brood: flat tan caps; drone: raised bullet caps","Sunken dark caps = disease — investigate immediately","Good pattern: compact, few gaps, consistent colour"]},
        {title:"🐝 Swarm Prevention",color:C.amber,content:["Inspect every 7 days April–June","Destroy all queen cells (except in artificial swarm)","Ensure colony always has space — add supers early","Consider making a nucleus colony to relieve pressure","Clip queen wing as temporary deterrent (controversial)"]},
        {title:"🍯 Harvesting Honey",color:C.honey,content:["Only harvest fully capped frames","Moisture must be below 20% — check with refractometer","Extract on a warm day — honey flows easier","Leave 20kg winter stores minimum — never strip the hive","Label correctly: weight, producer, country, best before"]},
        {title:"❄️ Winter Prep",color:C.blue,content:["Complete varroa treatment before clustering (October)","Ensure 20kg+ stores or feed 2:1 syrup","Fit mouse guards — mice will nest inside","Reduce entrance, maintain ventilation","Tip hive slightly forward so condensation drains out","Never open below 10°C — you will chill and kill the cluster"]},
        {title:"🆘 Emergency Actions",color:C.red,content:["QUEENLESS: Introduce mated queen or combine with queenright colony","STARVATION: Apply fondant immediately — not syrup in cold weather","AFB SUSPECTED: Don't open/move. Contact bee inspector immediately","SWARMED: Check for viable queen cells or introduce new queen","ROBBING: Close entrance to 1 bee width, remove honey spillage"]},
      ].map(s=>(
        <div key={s.title} style={{...S.card,borderLeft:`4px solid ${s.color}`}}>
          <div style={{...S.h2,color:s.color}}>{s.title}</div>
          {s.content.map((c,i)=>(
            <div key={i} style={{display:"flex",gap:"8px",marginBottom:"5px",fontSize:"12px",color:C.cream}}>
              <span style={{color:s.color,flexShrink:0}}>▶</span><span>{c}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );

  // ── MODALS ─────────────────────────────────────────────────────────────
  const HiveModal=()=>(<div style={S.overlay} onClick={()=>setModal(null)}><div style={S.modal} onClick={e=>e.stopPropagation()}>
    <div style={S.h1}>🏠 Add New Hive</div>
    <Field label="Hive Name *"><input style={S.inp} value={fHive.name} onChange={e=>setFHive(p=>({...p,name:e.target.value}))} placeholder="e.g. Queen Beatrice"/></Field>
    <div style={S.row}><div style={S.col}><Field label="Location"><input style={S.inp} value={fHive.location} onChange={e=>setFHive(p=>({...p,location:e.target.value}))} placeholder="e.g. Garden"/></Field></div><div style={S.col}><Field label="Hive Type"><Sel value={fHive.type} onChange={v=>setFHive(p=>({...p,type:v}))} options={HIVE_TYPES}/></Field></div></div>
    <Field label="Colour Marker"><input type="color" value={fHive.color} onChange={e=>setFHive(p=>({...p,color:e.target.value}))} style={{width:"50px",height:"28px",border:"none",background:"none",cursor:"pointer"}}/></Field>
    <Field label="Notes"><textarea style={S.textarea} value={fHive.notes} onChange={e=>setFHive(p=>({...p,notes:e.target.value}))} placeholder="Bee breed, origin, notes..."/></Field>
    <div style={{display:"flex",gap:"8px"}}><button style={S.btn("primary")} onClick={saveHive}>Save</button><button style={S.btn("")} onClick={()=>setModal(null)}>Cancel</button></div>
  </div></div>);

  const InspModal=()=>(<div style={S.overlay} onClick={()=>setModal(null)}><div style={S.modal} onClick={e=>e.stopPropagation()}>
    <div style={S.h1}>📋 Log Inspection</div>
    <div style={S.row}><div style={S.col}><Field label="Hive *"><select style={S.inp} value={fInsp.hiveId} onChange={e=>setFInsp(p=>({...p,hiveId:e.target.value}))}><option value="">-- Select --</option>{hives.map(h=><option key={h.id} value={h.id}>{h.name}</option>)}</select></Field></div><div style={S.col}><Field label="Date"><input type="date" style={S.inp} value={fInsp.date} onChange={e=>setFInsp(p=>({...p,date:e.target.value}))}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Season"><Sel value={fInsp.season} onChange={v=>setFInsp(p=>({...p,season:v}))} options={SEASONS}/></Field></div><div style={S.col}><Field label="Weather"><Sel value={fInsp.weather} onChange={v=>setFInsp(p=>({...p,weather:v}))} options={WEATHER}/></Field></div><div style={S.col}><Field label="°C"><input type="number" style={S.inp} value={fInsp.tempC} onChange={e=>setFInsp(p=>({...p,tempC:e.target.value}))}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Health"><Sel value={fInsp.health} onChange={v=>setFInsp(p=>({...p,health:v}))} options={HEALTH}/></Field></div><div style={S.col}><Field label="Temperament"><Sel value={fInsp.temperament} onChange={v=>setFInsp(p=>({...p,temperament:v}))} options={TEMPERAMENT}/></Field></div></div>
    <Field label="Queen Status"><Sel value={fInsp.queen} onChange={v=>setFInsp(p=>({...p,queen:v}))} options={QUEEN_STATUS}/></Field>
    <div style={S.row}><div style={S.col}><Field label="Queen Mark"><input style={S.inp} value={fInsp.queenColor} onChange={e=>setFInsp(p=>({...p,queenColor:e.target.value}))} placeholder="e.g. Green 2024"/></Field></div><div style={S.col}><Field label="Weight (kg)"><input type="number" style={S.inp} value={fInsp.weight} onChange={e=>setFInsp(p=>({...p,weight:e.target.value}))}/></Field></div></div>
    <div style={{...S.h2,fontSize:"12px"}}>📊 Scores 0–10</div>
    <div style={S.row}>{[["Honey","honey",C.honey],["Brood","brood",C.green],["Population","population",C.blue],["Pollen","pollen",C.amber]].map(([l,k,c])=>(
      <div key={k} style={S.col}><Field label={l}><input type="number" min="0" max="10" style={{...S.inp,borderColor:c+"66"}} value={fInsp[k]} onChange={e=>setFInsp(p=>({...p,[k]:parseInt(e.target.value)||0}))}/></Field></div>
    ))}</div>
    <div style={S.row}><div style={S.col}><Field label="Varroa /100"><input type="number" min="0" style={S.inp} value={fInsp.varroa} onChange={e=>setFInsp(p=>({...p,varroa:parseInt(e.target.value)||0}))}/></Field></div><div style={S.col}><Field label="Method"><Sel value={fInsp.varroaMethod} onChange={v=>setFInsp(p=>({...p,varroaMethod:v}))} options={["Alcohol Wash","Sugar Roll","Sticky Board","Drone Count","None"]}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Disease"><Sel value={fInsp.disease} onChange={v=>setFInsp(p=>({...p,disease:v}))} options={DISEASE_LIST}/></Field></div><div style={S.col}><Field label="Treatment"><Sel value={fInsp.treatment} onChange={v=>setFInsp(p=>({...p,treatment:v}))} options={TREATMENTS}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Dose"><input style={S.inp} value={fInsp.treatmentDose} onChange={e=>setFInsp(p=>({...p,treatmentDose:e.target.value}))} placeholder="e.g. 2.3g"/></Field></div><div style={S.col}><Field label="Withdrawal Days"><input type="number" min="0" style={S.inp} value={fInsp.withdrawalDays} onChange={e=>setFInsp(p=>({...p,withdrawalDays:parseInt(e.target.value)||0}))}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Supers"><input type="number" min="0" style={S.inp} value={fInsp.supers} onChange={e=>setFInsp(p=>({...p,supers:parseInt(e.target.value)||0}))}/></Field></div><div style={S.col}><Field label="Frames"><input type="number" min="0" style={S.inp} value={fInsp.frameCount} onChange={e=>setFInsp(p=>({...p,frameCount:parseInt(e.target.value)||0}))}/></Field></div><div style={S.col}><Field label="Swarm Cells"><select style={S.inp} value={fInsp.swarmCells} onChange={e=>setFInsp(p=>({...p,swarmCells:e.target.value==="true"}))}><option value="false">No</option><option value="true">YES</option></select></Field></div></div>
    <Field label="Feed Type"><Sel value={fInsp.feedType} onChange={v=>setFInsp(p=>({...p,feedType:v}))} options={FEED_TYPES}/></Field>
    <Field label="Notes"><textarea style={S.textarea} value={fInsp.notes} onChange={e=>setFInsp(p=>({...p,notes:e.target.value}))} placeholder="Observations, actions taken..."/></Field>
    <div style={{display:"flex",gap:"8px"}}><button style={S.btn("primary")} onClick={saveInsp}>Save</button><button style={S.btn("")} onClick={()=>setModal(null)}>Cancel</button></div>
  </div></div>);

  const HarvestModal=()=>(<div style={S.overlay} onClick={()=>setModal(null)}><div style={S.modal} onClick={e=>e.stopPropagation()}>
    <div style={S.h1}>🍯 Log Harvest</div>
    <div style={S.row}><div style={S.col}><Field label="Hive *"><select style={S.inp} value={fHarvest.hiveId} onChange={e=>setFHarvest(p=>({...p,hiveId:e.target.value}))}><option value="">-- Select --</option>{hives.map(h=><option key={h.id} value={h.id}>{h.name}</option>)}</select></Field></div><div style={S.col}><Field label="Date"><input type="date" style={S.inp} value={fHarvest.date} onChange={e=>setFHarvest(p=>({...p,date:e.target.value}))}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Honey Type"><Sel value={fHarvest.honeyType} onChange={v=>setFHarvest(p=>({...p,honeyType:v}))} options={HONEY_TYPES}/></Field></div><div style={S.col}><Field label="Frames"><input type="number" min="0" style={S.inp} value={fHarvest.frames} onChange={e=>setFHarvest(p=>({...p,frames:parseInt(e.target.value)||0}))}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Weight (kg)"><input type="number" step="0.1" style={S.inp} value={fHarvest.weight} onChange={e=>setFHarvest(p=>({...p,weight:parseFloat(e.target.value)||0}))}/></Field></div><div style={S.col}><Field label="Moisture %"><input type="number" step="0.1" style={S.inp} value={fHarvest.moisture} onChange={e=>setFHarvest(p=>({...p,moisture:parseFloat(e.target.value)||0}))}/></Field></div><div style={S.col}><Field label="Jars"><input type="number" min="0" style={S.inp} value={fHarvest.jarCount} onChange={e=>setFHarvest(p=>({...p,jarCount:parseInt(e.target.value)||0}))}/></Field></div></div>
    <Field label="Extraction Method"><Sel value={fHarvest.extracted} onChange={v=>setFHarvest(p=>({...p,extracted:v}))} options={["Radial Extractor","Tangential Extractor","Crush & Strain","Flow Hive Tap","Cut Comb","Press"]}/></Field>
    {fHarvest.moisture>20&&<div style={S.alert(C.red)}>⚠️ Moisture above 20% — may ferment. Allow to ripen further.</div>}
    <Field label="Notes"><textarea style={S.textarea} value={fHarvest.notes} onChange={e=>setFHarvest(p=>({...p,notes:e.target.value}))} placeholder="Colour, flavour, quality notes..."/></Field>
    <div style={{display:"flex",gap:"8px"}}><button style={S.btn("primary")} onClick={saveHarvest}>Save</button><button style={S.btn("")} onClick={()=>setModal(null)}>Cancel</button></div>
  </div></div>);

  const ExpenseModal=()=>(<div style={S.overlay} onClick={()=>setModal(null)}><div style={S.modal} onClick={e=>e.stopPropagation()}>
    <div style={S.h1}>💰 Add Expense</div>
    <div style={S.row}><div style={S.col}><Field label="Date"><input type="date" style={S.inp} value={fExpense.date} onChange={e=>setFExpense(p=>({...p,date:e.target.value}))}/></Field></div><div style={S.col}><Field label="Category"><Sel value={fExpense.category} onChange={v=>setFExpense(p=>({...p,category:v}))} options={["Equipment","Treatment","Feed","Queen","Education","Insurance","Transport","Packaging","Other"]}/></Field></div></div>
    <Field label="Item *"><input style={S.inp} value={fExpense.item} onChange={e=>setFExpense(p=>({...p,item:e.target.value}))} placeholder="e.g. Oxalic Acid 500g"/></Field>
    <Field label="Cost (£)"><input type="number" step="0.01" style={S.inp} value={fExpense.cost} onChange={e=>setFExpense(p=>({...p,cost:e.target.value}))} placeholder="0.00"/></Field>
    <Field label="Notes"><textarea style={S.textarea} value={fExpense.notes} onChange={e=>setFExpense(p=>({...p,notes:e.target.value}))} placeholder="Optional notes..."/></Field>
    <div style={{display:"flex",gap:"8px"}}><button style={S.btn("primary")} onClick={saveExpense}>Save</button><button style={S.btn("")} onClick={()=>setModal(null)}>Cancel</button></div>
  </div></div>);

  const TaskModal=()=>(<div style={S.overlay} onClick={()=>setModal(null)}><div style={S.modal} onClick={e=>e.stopPropagation()}>
    <div style={S.h1}>✅ Add Task</div>
    <Field label="Task *"><textarea style={S.textarea} value={fTask.task} onChange={e=>setFTask(p=>({...p,task:e.target.value}))} placeholder="e.g. Check varroa count after treatment"/></Field>
    <div style={S.row}><div style={S.col}><Field label="Hive (optional)"><select style={S.inp} value={fTask.hiveId} onChange={e=>setFTask(p=>({...p,hiveId:e.target.value}))}><option value="">General</option>{hives.map(h=><option key={h.id} value={h.id}>{h.name}</option>)}</select></Field></div><div style={S.col}><Field label="Due Date"><input type="date" style={S.inp} value={fTask.due} onChange={e=>setFTask(p=>({...p,due:e.target.value}))}/></Field></div><div style={S.col}><Field label="Priority"><Sel value={fTask.priority} onChange={v=>setFTask(p=>({...p,priority:v}))} options={["High","Medium","Low"]}/></Field></div></div>
    <div style={{display:"flex",gap:"8px"}}><button style={S.btn("primary")} onClick={saveTask}>Save</button><button style={S.btn("")} onClick={()=>setModal(null)}>Cancel</button></div>
  </div></div>);

  const QueenModal=()=>(<div style={S.overlay} onClick={()=>setModal(null)}><div style={S.modal} onClick={e=>e.stopPropagation()}>
    <div style={S.h1}>👑 Record Queen</div>
    <div style={S.row}><div style={S.col}><Field label="Hive *"><select style={S.inp} value={fQueen.hiveId} onChange={e=>setFQueen(p=>({...p,hiveId:e.target.value}))}><option value="">-- Select --</option>{hives.map(h=><option key={h.id} value={h.id}>{h.name}</option>)}</select></Field></div><div style={S.col}><Field label="Date Introduced"><input type="date" style={S.inp} value={fQueen.introduced} onChange={e=>setFQueen(p=>({...p,introduced:e.target.value}))}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Breed"><input style={S.inp} value={fQueen.breed} onChange={e=>setFQueen(p=>({...p,breed:e.target.value}))} placeholder="e.g. Italian"/></Field></div><div style={S.col}><Field label="Status"><Sel value={fQueen.status} onChange={v=>setFQueen(p=>({...p,status:v}))} options={["Active","Superseded","Replaced","Dead","Unknown"]}/></Field></div></div>
    <div style={S.row}><div style={S.col}><Field label="Marked?"><select style={S.inp} value={fQueen.marked} onChange={e=>setFQueen(p=>({...p,marked:e.target.value==="true"}))}><option value="false">No</option><option value="true">Yes</option></select></Field></div><div style={S.col}><Field label="Mark Colour"><input style={S.inp} value={fQueen.markColor} onChange={e=>setFQueen(p=>({...p,markColor:e.target.value}))} placeholder="e.g. Green (2024)"/></Field></div></div>
    <Field label="Notes"><textarea style={S.textarea} value={fQueen.notes} onChange={e=>setFQueen(p=>({...p,notes:e.target.value}))} placeholder="Temperament, laying quality, source..."/></Field>
    <div style={{display:"flex",gap:"8px"}}><button style={S.btn("primary")} onClick={saveQueen}>Save</button><button style={S.btn("")} onClick={()=>setModal(null)}>Cancel</button></div>
  </div></div>);

  const activeTab=tab==="hivedetail"?"hives":tab;
  return (
    <div style={S.app}>
      <div style={S.header}>
        <div style={S.logoWrap}>
          <span style={{fontSize:"26px"}}>🐝</span>
          <div><div style={S.logoText}>BeesMaster Pro</div><div style={S.logoSub}>Complete Apiary Suite</div></div>
        </div>
        <div style={S.nav}>
          {TABS.map(([id,label])=>(
            <button key={id} style={S.nb(activeTab===id)} onClick={()=>{if(id==="hives"&&tab==="hivedetail")setTab("hives");else setTab(id);}}>
              {label}{id==="tasks"&&overdue>0&&<span style={{marginLeft:"3px",background:C.red,color:"#fff",borderRadius:"8px",padding:"0 4px",fontSize:"9px"}}>{overdue}</span>}
            </button>
          ))}
        </div>
      </div>
      {tab==="dashboard"&&<Dashboard/>}
      {tab==="hives"&&<HivesList/>}
      {tab==="hivedetail"&&<HiveDetail/>}
      {tab==="inspections"&&<Inspections/>}
      {tab==="harvest"&&<Harvest/>}
      {tab==="queens"&&<Queens/>}
      {tab==="health"&&<Health/>}
      {tab==="tasks"&&<Tasks/>}
      {tab==="expenses"&&<Expenses/>}
      {tab==="calendar"&&<Calendar/>}
      {tab==="research"&&<Research/>}
      {tab==="suppliers"&&<Suppliers/>}
      {tab==="startup"&&<Startup/>}
      {tab==="diy"&&<Diy/>}
      {tab==="guide"&&<Guide/>}
      {modal==="hive"&&<HiveModal/>}
      {modal==="inspection"&&<InspModal/>}
      {modal==="harvest"&&<HarvestModal/>}
      {modal==="expense"&&<ExpenseModal/>}
      {modal==="task"&&<TaskModal/>}
      {modal==="queen"&&<QueenModal/>}
    </div>
  );
}
